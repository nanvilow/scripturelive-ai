// v0.5.48 — Admin Settings persistence.
//
// GET  → returns the current owner-saved RuntimeConfig + the compiled
//        defaults so the UI can render "current vs default" hints.
// POST → merges the supplied patch into RuntimeConfig and persists it
//        to ~/.scripturelive/license.json under `config`. Server-side
//        helpers in plans.ts (getEffectivePlans, getEffectiveMoMo,
//        getEffectiveNotificationTargets) consult this on every call,
//        so changes apply without a process restart.

import { NextRequest, NextResponse } from 'next/server'
import { getConfig, saveConfig, getFile, type RuntimeConfig } from '@/lib/licensing/storage'
import { requireAdmin, revokeAllSessions, buildClearCookie } from '@/lib/licensing/admin-auth'
import { cloudPullAdminLedgerCached } from '@/lib/licensing/cloud-pull-cache'
import {
  PLANS,
  MOMO_RECIPIENT,
  NOTIFICATION_EMAIL,
  NOTIFICATION_WHATSAPP,
} from '@/lib/licensing/plans'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

interface Defaults {
  trialMinutes: number
  momoName: string
  momoNumber: string
  notifyEmail: string
  whatsappNumber: string
  planPrices: Record<string, number>
}

function defaults(): Defaults {
  const planPrices: Record<string, number> = {}
  for (const p of PLANS) planPrices[p.code] = p.amountGhs
  return {
    trialMinutes: 60,
    momoName: MOMO_RECIPIENT.name,
    momoNumber: MOMO_RECIPIENT.number,
    notifyEmail: NOTIFICATION_EMAIL,
    whatsappNumber: NOTIFICATION_WHATSAPP,
    planPrices,
  }
}

export async function GET(req: NextRequest) {
  const guard = requireAdmin(req)
  if (guard) return guard
  // v0.7.160 — Cross-device admin sync also pulls config (prices,
  // momo recipient, trial duration, notification targets, etc.) so
  // an operator who tweaks pricing on the cloud / phone admin sees
  // the updated values on their desktop the next time the Settings
  // tab opens. v0.7.173 — TTL-cached + coalesced; see cloud-pull-cache.ts.
  try { await cloudPullAdminLedgerCached() } catch { /* never block */ }
  const config = getConfig() ?? {}
  return NextResponse.json(
    { config, defaults: defaults() },
    { headers: { 'Cache-Control': 'no-store' } },
  )
}

interface SavePayload {
  adminPassword?: string | null
  trialMinutes?: number | null
  momoName?: string | null
  momoNumber?: string | null
  whatsappNumber?: string | null
  notifyEmail?: string | null
  planPriceOverrides?: Record<string, number | null> | null
  /** v0.5.52 — admin-paste cloud key overrides. */
  adminOpenAIKey?: string | null
  adminDeepgramKey?: string | null
  /** v0.7.29 — Phase 2 v0.8.0 — LLM voice classifier opt-in. */
  enableLlmClassifier?: boolean | null
  llmClassifierConfidenceFloor?: number | null
  /** v0.7.153 — Cross-device admin sync credential (the cloud
   *  install's masterCode). Per-PC; never leaves this device. */
  cloudAdminCode?: string | null
}

function clean(v: unknown): unknown {
  if (v === null) return null
  if (typeof v === 'string') {
    const t = v.trim()
    return t === '' ? null : t
  }
  return v
}

export async function POST(req: NextRequest) {
  const guard = requireAdmin(req)
  if (guard) return guard
  let body: SavePayload
  try {
    body = (await req.json()) as SavePayload
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
  }

  const patch: Partial<Record<keyof RuntimeConfig, unknown>> = {}

  // v0.7.3 — Track whether the admin password is being changed so
  // we can invalidate every other session at the end of the patch.
  // Otherwise the operator's pre-change 12h cookie would keep
  // working against the new password (their bug report:
  // "I changed the password, exit, re-enter — no prompt").
  let adminPasswordChanged = false
  if ('adminPassword' in body) {
    const newVal = clean(body.adminPassword)
    const oldVal = getConfig()?.adminPassword ?? null
    patch.adminPassword = newVal
    if (newVal !== oldVal) adminPasswordChanged = true
  }
  if ('adminOpenAIKey' in body) patch.adminOpenAIKey = clean(body.adminOpenAIKey)
  if ('adminDeepgramKey' in body) patch.adminDeepgramKey = clean(body.adminDeepgramKey)
  // v0.7.153 — Cross-device admin sync credential. Operator pastes
  // the cloud install's masterCode here (visible on the cloud's Admin
  // → Overview tab). Strictly per-PC; the storage layer's snapshot
  // extractor strips this from any cloud push.
  if ('cloudAdminCode' in body) patch.cloudAdminCode = clean(body.cloudAdminCode)

  // v0.7.29 — LLM voice classifier opt-in. Boolean: explicit null
  // clears the override; explicit boolean overrides; missing key is
  // a no-op (preserves the existing value).
  if ('enableLlmClassifier' in body) {
    if (body.enableLlmClassifier === null) patch.enableLlmClassifier = null
    else if (typeof body.enableLlmClassifier === 'boolean') {
      patch.enableLlmClassifier = body.enableLlmClassifier
    }
  }
  if ('llmClassifierConfidenceFloor' in body) {
    if (body.llmClassifierConfidenceFloor === null) {
      patch.llmClassifierConfidenceFloor = null
    } else if (
      typeof body.llmClassifierConfidenceFloor === 'number' &&
      body.llmClassifierConfidenceFloor > 0
    ) {
      // Clamp 1..100. Floors outside this range have no useful
      // semantics for the classifier (which returns confidence on a
      // 0..100 scale).
      patch.llmClassifierConfidenceFloor = Math.min(
        100,
        Math.max(1, Math.floor(body.llmClassifierConfidenceFloor)),
      )
    }
  }
  if ('momoName' in body) patch.momoName = clean(body.momoName)
  if ('momoNumber' in body) patch.momoNumber = clean(body.momoNumber)
  if ('whatsappNumber' in body) patch.whatsappNumber = clean(body.whatsappNumber)
  if ('notifyEmail' in body) patch.notifyEmail = clean(body.notifyEmail)

  if ('trialMinutes' in body) {
    if (body.trialMinutes === null) {
      patch.trialMinutes = null
    } else if (typeof body.trialMinutes === 'number' && body.trialMinutes > 0) {
      patch.trialMinutes = Math.min(24 * 60, Math.max(1, Math.floor(body.trialMinutes)))
    }
  }

  if ('planPriceOverrides' in body && body.planPriceOverrides) {
    const map: Record<string, number> = {}
    for (const [code, value] of Object.entries(body.planPriceOverrides)) {
      if (value === null) continue // skip — null means "clear"
      if (typeof value === 'number' && value > 0) {
        map[code] = Math.round(value)
      }
    }
    // Merge with existing overrides so per-row clears work.
    // existing may have undefined values per the partial type — strip them.
    const existing = getConfig()?.planPriceOverrides ?? {}
    const merged: Record<string, number> = {}
    for (const [k, v] of Object.entries(existing)) {
      if (typeof v === 'number') merged[k] = v
    }
    for (const [k, v] of Object.entries(map)) merged[k] = v
    // Apply explicit clears (null) by removing those keys.
    for (const [code, value] of Object.entries(body.planPriceOverrides)) {
      if (value === null) delete merged[code]
    }
    patch.planPriceOverrides = merged
  }

  const next = saveConfig(patch)

  // v0.7.3 — When the admin password changes, blow away ALL active
  // sessions (including the caller's). The response also clears the
  // caller's cookie so the modal's next /whoami probe gets 401 and
  // re-renders the password gate.
  const headers: Record<string, string> = { 'Cache-Control': 'no-store' }
  if (adminPasswordChanged) {
    const cleared = revokeAllSessions()
    // eslint-disable-next-line no-console
    console.warn(`[admin-config] Admin password changed — revoked ${cleared} session(s)`)
    headers['Set-Cookie'] = buildClearCookie()
  }

  return NextResponse.json(
    {
      ok: true,
      config: next,
      defaults: defaults(),
      ...(adminPasswordChanged ? { reauthRequired: true } : {}),
    },
    { headers },
  )
}
