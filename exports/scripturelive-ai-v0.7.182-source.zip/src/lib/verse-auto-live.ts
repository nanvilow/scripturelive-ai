// v0.7.107 — Per-column auto-live thresholds + continuous gate per
// operator spec ("Auto LIVE Detection System Fix — VERY IMPORTANT").
//
// REVERSAL of the v0.7.106 single-floor model. Operator complaint:
// "auto-live detection only works once and stops". Two root causes:
//
//   1) v0.7.106 used a 3.5 s LIVE_HOLD_MS dwell window between fires.
//      In real preaching, the auto-fire effect in logos-shell only
//      re-runs when `detectedVerses` changes. If a new top arrives
//      DURING the 3.5 s window the helper refused to fire, and once
//      the window elapsed nothing re-triggered the effect — so the
//      app appeared to "lock" after the first fire. v0.7.107 sets
//      LIVE_HOLD_MS = 0 (continuous, no anti-flicker dwell). The
//      ONLY duplicate-block is the id===currentLiveId no-refire short-
//      circuit, which the spec explicitly allows ("No duplicate
//      blocking unless same exact verse is already LIVE").
//
//   2) v0.7.106 used a single 0.65 floor for both detector pipelines.
//      The spec wants column-specific thresholds:
//        • COL 1 "Auto Verse Match"        → semantic, ≥ 80%
//        • COL 2 "Bible Reference Quoted"  → explicit, ≥ 60%
//        • COL 3 "Suggested Verses"        → 10-49%, manual only
//      Lower floor for explicit (regex hits are crisp; 60% is plenty).
//      Higher floor for semantic (paraphrase / embedding hits are
//      softer; 80% guards against false positives going live).
//
// The "Auto Verse Match" column header in logos-shell is rendered
// over our SEMANTIC pipeline (id === 'explicit' is the regex hits
// labelled "Bible Reference Quoted" in the UI). This is the
// historical wiring; we keep the internal source tags 'explicit' /
// 'semantic' but apply the new thresholds per the operator-facing
// labels. See COLUMN_AUTO_LIVE_MIN below for the source→threshold
// map and `pickAutoLiveBySource` for the floor lookup.
//
// Suggestions column accepts the literal 10-49% band per the spec
// ("DO NOT auto-send live. Only send to LIVE when the user double-
// clicks"). Anything above 49% that didn't qualify for its column's
// auto-fire floor is currently dropped from the visible UI — this
// is the spec's intent (the 50-79% semantic / 50-59% explicit gap
// is a false-positive zone we deliberately don't surface).
export type DetectionSource = 'explicit' | 'semantic' | 'suggestion'

export interface RankedVerse {
  id: string
  confidence?: number
  detectedAt?: Date | string | number
  source?: DetectionSource
}

// v0.7.108 — Column-specific auto-live floors per operator spec.
//   • EXPLICIT (regex / Reference-Engine hits, labelled "Auto Verse
//     Match" in the UI): ≥ 0.60.
//   • SEMANTIC (preacher-phrase / keyword / AI cosine embeddings,
//     labelled "Bible Reference Quoted" in the UI — paraphrased
//     quotations): LOWERED 0.80 → 0.55. Operator: "Bible Reference
//     Quoted column, Paraphrased quotations auto-live should be at
//     55% to 100%". Paraphrase recall is more important than
//     precision in live preaching — the previous 0.80 floor was so
//     strict it almost never fired in real audio.
// v0.7.133 — Lowered EXPLICIT floor 0.60 → 0.58. Operator escalation
// after v0.7.131: "WHAT I WANT IS ANY Bible Reference DETECTED [AS LOW
// AS] 58% SHOULD AUTO GO LIVE." Same screenshot as v0.7.131
// (https://imgur.com/a/8MmmIPI) — a regex address-parse hit on Acts 16
// at the operator's required floor must auto-fire and must also break
// any in-flight semantic high-conf lock (see
// CROSS_PIPELINE_CORROBORATION_MIN below — also lowered to 0.58 in
// lockstep so the new floor is honoured both for fresh fires and for
// breaking an existing lock).
export const EXPLICIT_AUTO_LIVE_MIN = 0.58
// v0.7.127 — Lowered SEMANTIC floor 0.55 → 0.50 to close the
// 50–54 % dead gap between the suggestions cap (<0.50) and the
// previous semantic floor (≥0.55). Operator screenshot showed a
// 52 % Matthew 4:19 paint into "SUGGESTED VERSES" then immediately
// vanish to "Low-confidence guesses (10–49%)" because nothing in the
// gap had a home column. Mirrors the v0.7.114 fix that closed the
// 55–59 % gap by aligning the suggestion-tag threshold with this
// floor (see speech-provider.tsx L1827 + L1984 — both also moved
// from `< 0.55` to `< 0.50` in v0.7.127). Auto-go-live is still
// gated by the per-source stability + 1.25 s anti-flicker dwell, so
// the lower visibility floor does NOT mean every 50 % hit fires
// immediately — it means the operator can SEE 50 %+ semantic hits in
// COL 2 instead of having them disappear into a typography gap.
export const SEMANTIC_AUTO_LIVE_MIN = 0.5

const COLUMN_AUTO_LIVE_MIN: Record<Exclude<DetectionSource, 'suggestion'>, number> = {
  explicit: EXPLICIT_AUTO_LIVE_MIN,
  semantic: SEMANTIC_AUTO_LIVE_MIN,
}

// Generic "is this auto-live eligible at all" floor — the LOWEST of
// the per-source minima. Kept as a back-compat export so older
// callers (and pickAutoLiveMatch below) still resolve.
export const AUTO_LIVE_MIN_CONFIDENCE = Math.min(
  EXPLICIT_AUTO_LIVE_MIN,
  SEMANTIC_AUTO_LIVE_MIN,
)

// Suggestions column: literal 10-49% band per spec.
export const SUGGESTION_MIN_CONFIDENCE = 0.1
export const SUGGESTION_MAX_EXCLUSIVE = 0.5
export const LIVE_COLUMN_MIN_CONFIDENCE = AUTO_LIVE_MIN_CONFIDENCE
export const ALTERNATIVE_MIN_CONFIDENCE = SUGGESTION_MIN_CONFIDENCE

// v0.7.107 — Stability stays at 1 frame (real-time per spec).
export const STABILITY_MIN_FRAMES = 1

// v0.7.109 — Anti-flicker dwell RE-ENABLED at 1250 ms.
// Operator spec: "If there's a next Bible verse or Bible Reference
// detection, let the previous Bible verse or Bible Reference
// detected stay live for about 1 to 1.5 sec." 1250 ms is the
// midpoint of that range — enough breathing room for the
// congregation to read the previous verse before the swap, short
// enough that the projector still feels live.
//
// Within `lastFireAtMs + LIVE_HOLD_MS` of a previous fire the gate
// returns fire=false with the gate UNCHANGED so the next call can
// re-evaluate. Once the window elapses, the next NEW qualifying
// detection (different id from currentLiveId) fires immediately.
// The id===currentLiveId no-refire short-circuit still applies.
// v0.7.116 — Lowered 1250 → 500. Operator complaint: "when a
// detection are being made at Bible Reference Quoted and Auto Verse
// Match detection is already live display, it doesn't switch to the
// new detection found in Bible Reference Quoted." The 1250 ms dwell
// window blocked ALL cross-column switching for 1.25 s after every
// fire — long enough that a brand-new high-confidence detection from
// the OTHER column would be silently swallowed if it landed during
// that window. 500 ms is still enough breathing room for the
// congregation to register the previous verse, but short enough that
// new detections feel immediate. Combined with v0.7.116's source-
// crossing dwell bypass below, cross-column switching now lands on
// the projector within ~half a second of detection.
export const LIVE_HOLD_MS = 500

// v0.7.117 — READ-LOCK ("Sticky live verse"). Operator complaint:
// "Can you lock down the accurately detected Bible verse that's in
// live display until the AI detects another accurate one? Because
// when an accurate Bible verse is detected and a user is reading
// from the live display before you will see the AI detector will
// detect another word from what is being read from the previous
// Bible detection and then will replace it with what it detected
// when they are reading from the live displayed one, which is not
// fine."
//
// Root cause: when a verse fires live, the operator (or preacher)
// reads it aloud. The transcript then says the verse text, the
// catalogue / semantic matcher detects a NEARBY verse (same chapter
// ±1-2, or a verse sharing the same opening clause), and the
// auto-fire helper happily swaps it in. Result: the projector
// flickers off the correct verse.
//
// Fix: For LIVE_STICKY_MS (8000 ms = 8 s) after a verse goes live,
// gate any new fire by these stricter rules:
//   1. Same reference as currentLive → never re-fire (existing rule).
//   2. New candidate confidence < currentLiveConfidence + 0.10 → BLOCK.
//      Stops same-chapter "near-misses" with similar confidence from
//      hijacking the live verse during read-back.
//   3. Otherwise allow — a clearly-better detection (e.g. an explicit
//      regex hit at 0.95 when current live is a semantic 0.65) WILL
//      override even within the read-lock.
// After the 4 s window the helper falls back to v0.7.116's normal
// 500 ms dwell and the operator gets responsive cross-column swaps
// for the next verse the preacher quotes. v0.7.169: lowered from
// 8000 → 4000 after operator reported "AI detector very slow at
// detecting and very slow at listening accurately." The previous 8 s
// window was tuned to filter near-miss noise but in field use it
// made the projector feel "stuck" for a full 8 s after every verse —
// preachers move on faster than that. 4 s still filters out the
// catalogue-near-miss flutter (which collapses within 1-2 s of the
// initial detection) but unblocks responsive cross-column swaps for
// rapid sermon flow.
export const LIVE_STICKY_MS = 4000

// Minimum confidence delta required for a new candidate to override
// the live verse during the read-lock window. 0.10 is large enough
// to filter out catalogue near-misses (which usually score within a
// few hundredths of the correct hit) but small enough that a
// genuinely better detection from the other column still wins.
export const LIVE_STICKY_CONFIDENCE_DELTA = 0.1

// v0.7.120 — High-confidence read-lock floor.
// Operator escalation: COL 2 "Bible Reference Quoted" went live with a
// verbatim preacher quotation ("Suffer not a witch to live" → Exod
// 22:18, conf 0.85 hand-curated EXACT) and was IMMEDIATELY hijacked by
// a COL 1 "Auto Verse Match" detection of an unrelated reference,
// because the v0.7.117 read-lock only required candConf >= liveConf +
// 0.10 (so an explicit 0.95 vs semantic 0.85 = 0.10 delta exactly →
// override allowed).
//
// When the live verse came from a HIGH-CONFIDENCE source (>= 0.85,
// which corresponds to hand-curated EXACT 0.95 / hand-curated FUZZY
// 0.85 / explicit-regex 0.95) the operator's spoken intent is
// unambiguous — the projector should STAY THERE for the full sticky
// window regardless of what else the matcher sees in the noisy
// transcript trailing the quote. Only an explicit operator click in
// the Detected Verses card overrides.
//
// Below this threshold (semantic 0.55-0.84, auto-derived 0.65) the
// older delta-based logic still applies — those are softer detections
// and a clearly-better candidate should be allowed to swap in.
//
// v0.7.128 — High-confidence VS high-confidence escape hatch.
// Operator screenshot https://imgur.com/a/uf6ndTK: live = Deuteronomy
// 2:1 @ 100 % (came from a Chapter Navigator lookup that pre-loaded
// the chapter — explicit pipeline tagged it 1.0). Preacher then
// quoted "My help cometh from the Lord" verbatim → COL 2 "Bible
// Reference Quoted" detected Psalm 121:2 @ 95 % (semantic, hand-
// curated preacher-phrase EXACT). The v0.7.120 high-conf lock
// blocked the swap because liveIsHighConf = true and there was no
// escape clause — meaning the projector stayed on Deuteronomy 2:1
// while the preacher was actively quoting Psalms.
//
// v0.7.128 fix: when the live verse is high-conf AND the new
// candidate is ALSO ≥ LIVE_HIGH_CONF_LOCK, the lock yields and the
// newer detection wins (subject to the same-reference no-flicker
// guard). Two independent high-conf detections from different
// columns is a near-zero-false-positive signal that the preacher
// has moved to a new verse. A weak detection (e.g. semantic 0.65)
// against a high-conf live verse still cannot break the lock — the
// v0.7.120 protection against navigation/regex spurious hits
// hijacking a verbatim quote stays intact.
//
// v0.7.131 — Cross-pipeline corroboration escape hatch.
// Operator screenshot https://imgur.com/a/8MmmIPI: preacher said
// "Paul and Silas were locked up in prison" → COL 1 "Auto Verse
// Match" (semantic pipeline) had latched onto a phrase-only match
// at 1.00 confidence and gone live. Simultaneously COL 2 "Bible
// Reference Quoted" (explicit/regex pipeline) correctly detected
// the actual reference (Acts 16) at 0.70. v0.7.128's escape only
// fired when BOTH detections were ≥0.85, so a high-conf SEMANTIC
// false-positive could permanently lock out a moderate-confidence
// EXPLICIT correction — exactly the operator-reported bug.
//
// Insight: a high-conf same-pipeline near-miss is noise (the v0.7.120
// case — which we MUST keep blocked). But a moderate-conf detection
// from the OTHER pipeline is independent corroboration: two different
// matchers (regex address parser + semantic phrase matcher) seeing
// different content is a strong signal that the live verse is wrong
// and the preacher has moved on. v0.7.131 adds a cross-pipeline
// escape: if the candidate's source != the live verse's source AND
// the candidate clears CROSS_PIPELINE_CORROBORATION_MIN, the lock
// yields. Same-pipeline candidates still go through the original
// v0.7.120/v0.7.128 logic — the v0.7.120 protection against same-
// pipeline near-misses hijacking a verbatim quote is unchanged.
export const LIVE_HIGH_CONF_LOCK = 0.85

// v0.7.131 — Cross-pipeline corroboration floor.
//   • EXPLICIT column floor (v0.7.133): 0.58
//   • SEMANTIC column floor (v0.7.127): 0.50
//
// v0.7.135 — As of this version, BOTH cross-pipeline directions
// resolve to 0.58 (see CROSS_PIPELINE_SEMANTIC_VS_EXPLICIT_MIN
// docstring). The asymmetric protection introduced in v0.7.133
// has been removed at operator request — they want any 58%
// detection from EITHER pipeline to break a lock from the OTHER
// pipeline.
//
// v0.7.133 — Lowered 0.70 → 0.58 to match the new EXPLICIT auto-live
// floor and to honour the operator's literal directive: "MAKE THE
// 100% UNBLOCK ITSELF WHEN NEW VERSE IS DETECTED IN Bible Reference
// Quoted." The v0.7.131 0.70 boundary was the very floor the operator
// reported as still-blocked (cand@0.70 vs sticky semantic@1.00 — the
// floating-point boundary plus any upstream `source`-tag inconsistency
// kept the lock engaged). At 0.58 the escape fires at the same floor
// as the column itself, so any auto-live-eligible explicit detection
// is *by definition* allowed to break a same-instant semantic lock —
// no second, stricter gate to trip over. Same-pipeline near-misses
// still go through the v0.7.120/v0.7.128 path below (a same-pipeline
// near-miss is noise, not corroboration — that protection stays
// intact). Risk: a 0.58 semantic could now break an operator-loaded
// explicit chapter (the v0.7.120 case in reverse). Mitigated by
// asymmetric application: see passesReadLock — when the candidate is
// SEMANTIC and the live verse is EXPLICIT-high-conf (operator-loaded
// chapter), we keep the v0.7.131 0.70 floor; only EXPLICIT candidates
// against a SEMANTIC lock get the 0.58 escape (which is the bug the
// operator hit in production).
export const CROSS_PIPELINE_CORROBORATION_MIN = 0.58
// v0.7.135 — Operator escalation: re-asked v0.7.133 fix in EXACT
// reverse direction. The operator's screenshot pointed at "Auto
// Verse Match" (the UI label for the EXPLICIT pipeline) latched at
// 100%, blocking a 58% detection in "Bible Reference Quoted" (the
// UI label for the SEMANTIC pipeline) from going live. v0.7.133
// only opened the EXPLICIT-cand-vs-SEMANTIC-live direction; this
// (SEMANTIC cand vs EXPLICIT live) was still gated at 0.70 — the
// operator hit it again. Spec verbatim, second pass: "MAKE THE
// 100% UNBLOCK ITSELF WHEN NEW VERSE IS DETECTED IN Bible Reference
// Quoted WHEN IT 58% GOING." Floor dropped 0.70 → 0.58 — symmetric
// with CROSS_PIPELINE_CORROBORATION_MIN. The cross-pipeline escape
// is now uniformly 0.58 in BOTH directions: an auto-live-eligible
// detection from EITHER pipeline can break a high-conf lock from
// the OTHER pipeline. v0.7.120 operator-loaded-chapter protection
// is preserved for SAME-pipeline near-misses (the same-pipeline
// branch below still requires LIVE_HIGH_CONF_LOCK), and for cross-
// pipeline noise BELOW 0.58 (which is also below the column auto-
// live floor — won't surface anywhere in the UI). The constant is
// kept (rather than collapsing to one) so the test suite and any
// future tuning can address the two directions independently.
export const CROSS_PIPELINE_SEMANTIC_VS_EXPLICIT_MIN = 0.58

function detectedAtMs(v: RankedVerse): number {
  const d = v.detectedAt
  if (d == null) return 0
  if (typeof d === 'number') return d
  if (typeof d === 'string') return new Date(d).getTime() || 0
  if (d instanceof Date) return d.getTime()
  return 0
}

function sourceOf(v: RankedVerse): DetectionSource {
  return v.source ?? 'explicit'
}

function autoLiveMinFor(source: Exclude<DetectionSource, 'suggestion'>): number {
  return COLUMN_AUTO_LIVE_MIN[source]
}

// Pure ranking helper — picks the highest-confidence verse from the
// supplied list whose confidence ≥ AUTO_LIVE_MIN_CONFIDENCE (the
// LOWEST per-source floor). Used by legacy callers; new code paths
// should use pickAutoLiveBySource which respects the per-source
// floor for the requested column.
export function pickAutoLiveMatch<T extends RankedVerse>(detected: readonly T[]): T | null {
  if (!detected.length) return null
  const ranked = [...detected].sort((a, b) => {
    const dc = (b.confidence ?? 0) - (a.confidence ?? 0)
    if (dc !== 0) return dc
    const dt = detectedAtMs(b) - detectedAtMs(a)
    if (dt !== 0) return dt
    return b.id.localeCompare(a.id)
  })
  const top = ranked[0]
  if (!top || (top.confidence ?? 0) < AUTO_LIVE_MIN_CONFIDENCE) return null
  return top
}

// Per-pipeline pick. Returns the NEWEST verse tagged with the
// requested source whose confidence clears that source's auto-live
// floor (explicit ≥ 0.60, semantic ≥ 0.55). Returns null if no
// qualifying candidate exists.
//
// v0.7.107 — Newest-first (was confidence-desc). Operator spec:
// "Every NEW valid detection triggers LIVE continuously". A new
// 0.62 explicit hit must displace an older 0.95 hit, otherwise the
// projector stays stuck on whatever scored highest at the start of
// the sermon. Confidence is used only as a tiebreak for same-frame
// arrivals.
export function pickAutoLiveBySource<T extends RankedVerse>(
  detected: readonly T[],
  source: Exclude<DetectionSource, 'suggestion'>,
): T | null {
  const min = autoLiveMinFor(source)
  const candidates = detected.filter(
    (v) => sourceOf(v) === source && (v.confidence ?? 0) >= min,
  )
  if (!candidates.length) return null
  candidates.sort((a, b) => {
    const dt = detectedAtMs(b) - detectedAtMs(a)
    if (dt !== 0) return dt
    const dc = (b.confidence ?? 0) - (a.confidence ?? 0)
    if (dc !== 0) return dc
    return b.id.localeCompare(a.id)
  })
  return candidates[0]
}

// Suggestions column. Returns every detection in the 0.10–0.499
// band, ordered newest-first.
//
// v0.7.127 — Removed the `source === 'suggestion'` short-circuit
// that previously bypassed the upper-bound check. The bypass let
// upstream taggers leak ≥0.50-confidence detections into this
// column (e.g. AI cosine matcher returning 0.52 + tagged
// 'suggestion' by speech-provider.tsx pre-fix) — a 52 % Matthew
// 4:19 painted into the column whose own header reads
// "Low-confidence guesses (10–49%)". The band is now enforced
// strictly for ALL sources. The 'suggestion' tag remains a hint to
// downstream consumers (it never auto-fires) but it no longer
// overrides the column's confidence contract. Auto-derived FUZZY
// hits from the preacher-phrase pipeline (hard-coded conf=0.42 in
// speech-provider.tsx L1685–1689) still appear here because their
// confidence sits inside the band — the bypass was redundant for
// them anyway.
export function suggestionsFor<T extends RankedVerse>(detected: readonly T[]): T[] {
  return [...detected]
    .filter((v) => {
      const c = v.confidence ?? 0
      return c >= SUGGESTION_MIN_CONFIDENCE && c < SUGGESTION_MAX_EXCLUSIVE
    })
    .sort((a, b) => {
      const dt = detectedAtMs(b) - detectedAtMs(a)
      if (dt !== 0) return dt
      const dc = (b.confidence ?? 0) - (a.confidence ?? 0)
      if (dc !== 0) return dc
      return b.id.localeCompare(a.id)
    })
}

// Per-pipeline live-column listing. Uses the source-specific floor.
// v0.7.107 — Newest detection sits on TOP (matches operator spec:
// "always make new detection arrive on top of previous detections").
// Confidence is the secondary tiebreak only.
export function liveColumnFor<T extends RankedVerse>(
  detected: readonly T[],
  source: Exclude<DetectionSource, 'suggestion'>,
): T[] {
  const min = autoLiveMinFor(source)
  return [...detected]
    .filter((v) => sourceOf(v) === source && (v.confidence ?? 0) >= min)
    .sort((a, b) => {
      const dt = detectedAtMs(b) - detectedAtMs(a)
      if (dt !== 0) return dt
      const dc = (b.confidence ?? 0) - (a.confidence ?? 0)
      if (dc !== 0) return dc
      return b.id.localeCompare(a.id)
    })
}

// Legacy single-column alternatives helper (newest-first, ≥ 0.10).
export function alternativesFor<T extends RankedVerse>(
  detected: readonly T[],
  liveMatchId: string | null,
): T[] {
  return [...detected]
    .filter((v) => {
      if (v.id === liveMatchId) return false
      const c = v.confidence ?? 0
      return c >= SUGGESTION_MIN_CONFIDENCE
    })
    .sort((a, b) => {
      const dt = detectedAtMs(b) - detectedAtMs(a)
      if (dt !== 0) return dt
      const dc = (b.confidence ?? 0) - (a.confidence ?? 0)
      if (dc !== 0) return dc
      return b.id.localeCompare(a.id)
    })
}

// ─── Stability gate (per-pipeline frame counter) ──────────────────
//
// At default minFrames=1 (v0.7.106+) this is a pass-through: any
// candidate fires on its first observation. Kept because the test
// suite asserts the counter behaviour and callers can pass
// `minFrames > 1` for tighter gates.
export interface StabilityState {
  topId: string | null
  count: number
}

export const initialStabilityState: StabilityState = { topId: null, count: 0 }

export function evaluateStability<T extends RankedVerse>(
  prev: StabilityState,
  candidate: T | null,
  opts: { minFrames?: number } = {},
): { next: StabilityState; fire: boolean; verse: T | null } {
  const minFrames = opts.minFrames ?? STABILITY_MIN_FRAMES
  if (!candidate) {
    return { next: { topId: null, count: 0 }, fire: false, verse: null }
  }
  const sameAsPrev = prev.topId === candidate.id
  const count = sameAsPrev ? prev.count + 1 : 1
  const next: StabilityState = { topId: candidate.id, count }
  return { next, fire: count >= minFrames, verse: candidate }
}

// ─── Auto-fire gate state (per-source counters + last-fire clock) ─
//
// `lastFireAtMs` stamps the wall-clock of the most recent fire. The
// helper enforces the LIVE_HOLD_MS dwell window against this stamp
// so the previous verse stays live for ~1.25 s before the next
// qualifying detection can swap it out.
export interface AutoFireGateState {
  explicit: StabilityState
  semantic: StabilityState
  lastFireAtMs: number
  // v0.7.152 — Semantic-Owns-Live latch. CRITICAL CORRECTION of
  // v0.7.150/v0.7.151 which had the column→source mapping inverted
  // and protected the WRONG side. The actual mapping (verified at
  // logos-shell.tsx L2331-2334) is:
  //
  //   COL 1 "Auto Verse Match"      = source 'explicit'  (regex /
  //                                    Reference Engine v2 — pastor
  //                                    literally said the address)
  //   COL 2 "Bible Reference Quoted" = source 'semantic'  (preacher
  //                                    phrase / paraphrase engine)
  //
  // Operator's verbatim spec ("always display Bible Reference Quoted
  // column detected over Auto Verse Match") therefore translates to:
  // SEMANTIC must always preempt EXPLICIT, and the latch must freeze
  // the EXPLICIT (AVM) column once SEMANTIC (BRQ) has taken the
  // projector — exactly the opposite direction from v0.7.150/v0.7.151.
  //
  // The latch ARMS only when a SEMANTIC (BRQ) verse fires AND the
  // previously-live verse was an EXPLICIT (AVM) detection. While the
  // latch is on, explicit auto-fire is suppressed so the BRQ verse
  // stays on the projector and the audio-buffer-lagged repeat
  // address-detections of the just-preempted AVM verse can't knock
  // it off.
  //
  // The latch RELEASES when EITHER:
  //   (a) `currentLiveId` becomes null (STOP LIVE / CLEAR / BLACK), OR
  //   (b) the AVM column shows a NEW explicit verse different from
  //       the one we froze (`explicitTop.id !== frozenExplicitId`).
  //       Operator spec: "until it detect Auto Verse Match again"
  //       — when the pastor moves on and AVM picks up a different
  //       address, AVM is allowed to fire again.
  //
  // Explicit detections of the FROZEN verse keep populating the AVM
  // column for operator visibility (no UI suppression) — only the
  // auto-fire-to-live pathway is gated.
  semanticOwnsLive: boolean
  // The explicit verse id that was preempted by the semantic fire.
  // Null when no latch is armed. Used to detect "AVM detect again"
  // — when `explicitTop.id` differs from this id, the pastor has
  // moved on and the latch releases.
  frozenExplicitId: string | null
}

export const initialAutoFireGate: AutoFireGateState = {
  explicit: initialStabilityState,
  semantic: initialStabilityState,
  lastFireAtMs: 0,
  semanticOwnsLive: false,
  frozenExplicitId: null,
}

// Backwards-compat alias — older callers (and the existing
// useRef in logos-shell) reference these names.
export type PerSourceStabilityState = AutoFireGateState
export const initialPerSourceStability: PerSourceStabilityState = initialAutoFireGate

export type AutoFireDecision<T extends RankedVerse> =
  | { fire: false; nextStability: AutoFireGateState }
  | {
      fire: true
      verse: T
      source: 'explicit' | 'semantic'
      nextStability: AutoFireGateState
    }

// Legacy two-arg sticky decision (uses the LOWEST per-source floor).
// Kept for any external caller still resolving this name.
export function shouldFireAutoLive<T extends RankedVerse>(
  detected: readonly T[],
  currentLiveId: string | null,
): { fire: false } | { fire: true; verse: T; source: 'explicit' | 'semantic' } {
  if (currentLiveId) return { fire: false }
  const top = pickAutoLiveMatch(detected)
  if (!top) return { fire: false }
  return {
    fire: true,
    verse: top,
    source: sourceOf(top) === 'semantic' ? 'semantic' : 'explicit',
  }
}

// v0.7.109 — Source-aware auto-fire decision with per-column floors
// and a 1.25 s anti-flicker dwell window (previous verse stays live
// for ~1-1.5 s before the next qualifying detection swaps it).
//
// Inputs:
//   • `detected`        — full detectedVerses store array.
//   • `currentLiveId`   — id of the verse currently shown live, or null.
//                          The helper will NOT re-fire the same id.
//   • `gate`            — { explicit, semantic, lastFireAtMs } prior
//                          frame state.
//   • `opts.minFrames`  — override the 1-frame default (tests).
//   • `opts.holdMs`     — override the 1250 ms default (tests can
//                          pass 0 to disable the dwell, or a longer
//                          value to widen it).
//   • `opts.nowMs`      — override Date.now() (tests).
//
// Behaviour:
//   1. If less than `holdMs` (default 1250) ms have elapsed since
//      the last fire, return `fire: false` and leave gate unchanged
//      so the previous verse stays live for the dwell window.
//   2. Per-source pick + stability counter advance. If a counter has
//      reached `minFrames` AND its top is not the verse currently
//      live, fire it; explicit wins on tiebreak.
//   3. Suggestion-tagged candidates are ineligible to fire (they
//      don't appear in pickAutoLiveBySource, which filters on
//      'explicit' | 'semantic' only).
export function shouldFireAutoLiveStable<T extends RankedVerse & { reference?: string }>(
  detected: readonly T[],
  currentLiveId: string | null,
  gate: AutoFireGateState,
  opts: {
    minFrames?: number
    holdMs?: number
    nowMs?: number
    // v0.7.117 — Override the read-lock window (4 s default as of v0.7.169). Tests
    // can pass 0 to disable.
    stickyMs?: number
    // v0.7.117 — Override the confidence delta required to break the
    // read-lock (0.10 default).
    stickyDelta?: number
  } = {},
): AutoFireDecision<T> {
  const minFrames = opts.minFrames ?? STABILITY_MIN_FRAMES
  const holdMs = opts.holdMs ?? LIVE_HOLD_MS
  const stickyMs = opts.stickyMs ?? LIVE_STICKY_MS
  const stickyDelta = opts.stickyDelta ?? LIVE_STICKY_CONFIDENCE_DELTA
  const now = opts.nowMs ?? Date.now()

  // Hold window: enforced for `holdMs` ms after the last fire (500
  // by default per v0.7.116 spec — previous verse stays live for
  // ~0.5 s before any swap). Returned gate is unchanged so the
  // caller persists it without bumping counters.
  if (holdMs > 0 && gate.lastFireAtMs > 0 && now - gate.lastFireAtMs < holdMs) {
    return { fire: false, nextStability: gate }
  }

  const explicitTop = pickAutoLiveBySource(detected, 'explicit')
  const semanticTop = pickAutoLiveBySource(detected, 'semantic')

  const explicitGate = evaluateStability(gate.explicit, explicitTop, { minFrames })
  const semanticGate = evaluateStability(gate.semantic, semanticTop, { minFrames })
  // v0.7.152 — Semantic-Owns-Live latch reset (corrected direction).
  //   (a) STOP LIVE / CLEAR / BLACK clears live → reset both fields.
  //   (b) AVM column shows an EXPLICIT verse different from the
  //       frozen one → pastor has moved on (literally said a NEW
  //       address), release the latch ("until it detect Auto Verse
  //       Match again" per operator spec).
  let semanticOwnsLive = gate.semanticOwnsLive
  let frozenExplicitId = gate.frozenExplicitId
  if (currentLiveId == null) {
    semanticOwnsLive = false
    frozenExplicitId = null
  } else if (
    semanticOwnsLive &&
    frozenExplicitId != null &&
    explicitTop != null &&
    explicitTop.id !== frozenExplicitId
  ) {
    semanticOwnsLive = false
    frozenExplicitId = null
  }
  const nextGate: AutoFireGateState = {
    explicit: explicitGate.next,
    semantic: semanticGate.next,
    lastFireAtMs: gate.lastFireAtMs,
    semanticOwnsLive,
    frozenExplicitId,
  }

  // Spec-allowed optimization: don't refire whatever's already on
  // the projector ("No duplicate blocking unless same exact verse
  // is already LIVE").
  let explicitFire =
    explicitGate.fire && explicitGate.verse && explicitGate.verse.id !== currentLiveId
      ? explicitGate.verse
      : null
  let semanticFire =
    semanticGate.fire && semanticGate.verse && semanticGate.verse.id !== currentLiveId
      ? semanticGate.verse
      : null

  // ── v0.7.117 — READ-LOCK gate ────────────────────────────────────
  // Within `stickyMs` of the last fire, suppress new fires whose
  // confidence does not exceed the live verse by `stickyDelta`. This
  // stops same-chapter near-miss detections from hijacking the live
  // verse while the operator/preacher reads it aloud.
  //
  // The live verse is found by id in the detected[] list. If it has
  // been pruned from the list (rare — usually it's still there) the
  // read-lock degrades to "block any new fire below stickyDelta of
  // the current top". Either way the live projector slide stays put.
  if (
    stickyMs > 0 &&
    gate.lastFireAtMs > 0 &&
    now - gate.lastFireAtMs < stickyMs &&
    currentLiveId
  ) {
    const liveVerse = detected.find((v) => v.id === currentLiveId) ?? null
    const liveConf = liveVerse?.confidence ?? 0
    const liveRef = liveVerse?.reference ?? null
    const liveSource = liveVerse ? sourceOf(liveVerse) : null
    // v0.7.120 — High-confidence absolute lock. If the live verse
    // came from a verbatim hand-curated catalog hit (>= 0.85) the
    // operator's intent is unambiguous; block ALL cross-ref auto
    // swaps in the sticky window regardless of incoming candidate
    // confidence. Manual operator click still overrides because that
    // path doesn't go through this gate.
    const liveIsHighConf = liveConf >= LIVE_HIGH_CONF_LOCK
    const passesReadLock = (
      cand: T | null,
      candSource: 'explicit' | 'semantic',
    ): boolean => {
      if (!cand) return false
      // Same reference → not really a swap. Block (no visible flicker).
      if (liveRef && cand.reference === liveRef) return false
      const candConf = cand.confidence ?? 0
      // v0.7.131 — CROSS-PIPELINE corroboration escape (runs FIRST,
      // before the same-pipeline same-source rules). When the
      // candidate comes from a DIFFERENT detection pipeline than the
      // currently live verse, treat it as independent verification
      // that the preacher has moved on. The semantic phrase matcher
      // and the explicit address parser are causally independent
      // signals — when they DIS-agree on which reference is current,
      // the cross-pipeline disagreement is itself a strong signal
      // the live verse is wrong (typically a high-conf semantic
      // phrase false-positive being corrected by the regex address
      // parser, or vice versa). Allow the swap iff the candidate
      // clears CROSS_PIPELINE_CORROBORATION_MIN — comfortably above
      // both column auto-live floors so noise can't break through,
      // but reachable for a confident detection from the other
      // pipeline. Same-pipeline candidates still go through the
      // v0.7.120/v0.7.128 path below (a same-pipeline near-miss is
      // noise, not corroboration — must stay blocked).
      if (liveSource && candSource !== liveSource) {
        // v0.7.152 — SEMANTIC ALWAYS WINS OVER EXPLICIT (corrected
        // direction — v0.7.150/v0.7.151 had the column→source
        // mapping inverted). Operator's literal directive: "always
        // display Bible Reference Quoted column detected over Auto
        // Verse Match". Code mapping: BRQ = source 'semantic',
        // AVM = source 'explicit'. So a SEMANTIC candidate (BRQ —
        // preacher phrase / paraphrase) against an EXPLICIT live
        // verse (AVM — regex address) is unconditionally allowed
        // through the read-lock — the SEMANTIC_AUTO_LIVE_MIN (0.50)
        // column floor is the only gate. The paraphrase engine
        // firing means the pastor has actively moved on to quote a
        // verse; AVM regex hits often latch onto stale lookup-loaded
        // chapters or repeat audio-buffer detections of an address
        // the pastor said minutes ago, so the BRQ signal must
        // preempt unconditionally even when AVM is at 100%.
        if (candSource === 'semantic' && liveSource === 'explicit') {
          return true
        }
        // Reverse direction (EXPLICIT candidate vs SEMANTIC live)
        // keeps the v0.7.135 0.58 floor — protects a confidently-
        // detected paraphrase from a low-confidence regex address
        // mishear.
        return candConf >= CROSS_PIPELINE_CORROBORATION_MIN
      }
      // v0.7.120 — HIGH-CONF lock blocks all cross-ref auto swaps.
      // v0.7.128 — UNLESS the new candidate is also high-conf
      // (≥ LIVE_HIGH_CONF_LOCK). Two independent high-conf
      // detections means the preacher has demonstrably moved on
      // (e.g. lookup-loaded Deut 2:1 @ 1.0 → verbatim Psalm 121:2 @
      // 0.95 quoted from the pulpit). The newer detection wins.
      if (liveIsHighConf) return candConf >= LIVE_HIGH_CONF_LOCK
      return candConf >= liveConf + stickyDelta
    }
    if (!passesReadLock(explicitFire, 'explicit')) explicitFire = null
    if (!passesReadLock(semanticFire, 'semantic')) semanticFire = null
  }

  // v0.7.152 — Semantic-Owns-Live FREEZE on the explicit pipeline.
  // Once a semantic (Bible Reference Quoted) verse has taken the
  // projector AFTER preempting an explicit (Auto Verse Match) live
  // verse, explicit auto-fire is suppressed for as long as the AVM
  // column keeps showing the same preempted verse. Releases per the
  // arming/reset logic above.
  if (nextGate.semanticOwnsLive && currentLiveId) {
    explicitFire = null
  }

  // v0.7.152 — Tiebreak inverted from v0.7.151: SEMANTIC wins when
  // both fire same frame. Operator spec: "always display Bible
  // Reference Quoted [semantic] column detected over Auto Verse
  // Match [explicit]".
  if (semanticFire) {
    // Arm the latch ONLY if the previously-live verse was an
    // EXPLICIT (AVM) detection. Look up the prior live verse in the
    // detected list; if it has source='explicit' we know AVM was
    // showing it and we want to freeze AVM until it picks up a NEW
    // address. Re-firing semantic when a semantic was already live
    // (or no live) does NOT arm the latch — but if the latch was
    // already armed from a prior explicit→semantic transition, it's
    // preserved (carried in nextGate).
    const priorLive = currentLiveId
      ? detected.find((v) => v.id === currentLiveId) ?? null
      : null
    const priorLiveSource = priorLive ? sourceOf(priorLive) : null
    const armLatch = priorLiveSource === 'explicit'
    return {
      fire: true,
      verse: semanticFire,
      source: 'semantic',
      nextStability: armLatch
        ? {
            ...nextGate,
            lastFireAtMs: now,
            semanticOwnsLive: true,
            frozenExplicitId: currentLiveId,
          }
        : { ...nextGate, lastFireAtMs: now },
    }
  }
  if (explicitFire) {
    return {
      fire: true,
      verse: explicitFire,
      source: 'explicit',
      // Explicit firing means the latch was either never armed or
      // just released (otherwise explicitFire would have been
      // nulled above). Always clear the latch fields for safety.
      nextStability: {
        ...nextGate,
        lastFireAtMs: now,
        semanticOwnsLive: false,
        frozenExplicitId: null,
      },
    }
  }
  return { fire: false, nextStability: nextGate }
}
