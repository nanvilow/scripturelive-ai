# ScriptureLive AI — Desktop Build (Native NDI)

The desktop build wraps the Next.js app in Electron and adds a **native NDI sender** so you get real, click-to-enable NDI output — exactly like EasyWorship — instead of the browser-based screen-capture workflow.

> **NDI is a LAN protocol.** The desktop app must run on the same local network as the receiver (vMix, Wirecast, OBS, NDI Studio Monitor, etc.).

## What you get

- A standalone Windows installer (`.exe`, NSIS) and macOS disk image (`.dmg`).
- The full ScriptureLive AI UI in its own window.
- A new **"Native NDI Output"** panel in **Settings**:
  - Enable / Stop toggle
  - Source name (default `ScriptureLive`)
  - Resolution (720p / 1080p)
  - Frame rate (30 / 60 fps)
  - Live frame counter and broadcasting status
- Per-user SQLite database in the OS app-data folder.

## Prerequisites for building

You **must build on the target OS**:

- **Windows installer** → build on Windows
- **macOS DMG** → build on macOS

(Cross-compiling Electron apps that include native modules — like the NDI binding — is unreliable. Run the Windows build on Windows and the macOS build on macOS.)

Both platforms also need:

- Node.js 20+ and `pnpm` 9+
- The platform's C/C++ toolchain (Visual Studio Build Tools on Windows, Xcode Command Line Tools on macOS) — required to compile the NDI native binding.
- **NDI SDK 5+** installed at the default location:
  - Windows: `C:\Program Files\NDI\NDI 5 SDK`
  - macOS: `/Library/NDI SDK for Apple/`
  - Get it free at <https://ndi.video/sdk/>.
- **NDI Tools** (free) installed on every machine that will run the built app — provides the runtime the binary loads at startup. <https://ndi.video/tools/>

## Build steps

```bash
# from the repo root
pnpm install
cd artifacts/imported-app

# Windows
pnpm run package:win
# → release/ScriptureLive AI-0.2.0-Setup-x64.exe

# macOS
pnpm run package:mac
# → release/ScriptureLive AI-0.2.0-arm64.dmg
# → release/ScriptureLive AI-0.2.0-x64.dmg
```

## Recommended: automated cloud builds via GitHub Actions

A ready-to-use pipeline lives at `.github/workflows/release-desktop.yml`. Once
the project is pushed to a GitHub repo, tagging a release (`git tag v0.2.0 &&
git push origin v0.2.0`) triggers GitHub-hosted Windows and macOS runners to
build, sign-in-the-future, and upload installers as a GitHub Release. See
`.github/workflows/README.md` for the one-time setup (~ 2 minutes) and how to
point the `/download` page at the published assets.

## Publishing the installers so users can download them

The web app exposes a polished `/download` page with OS detection at
`https://<your-host>/download`. It reads `public/downloads/manifest.json` and
serves files via `/api/download/<platform>`.

Two ways to publish:

### Option A — host the files alongside the app (default)

1. Copy the build output from `release/` into `artifacts/imported-app/public/downloads/`,
   keeping the original filenames (the manifest's `filename` field must match).
2. Update `version` and `releaseNotes` in `public/downloads/manifest.json`.
3. Restart the server. The download page will pick up size and availability
   automatically from disk, and SHA-256 checksums will be computed on the
   first request and cached in memory.

### Option B — host on GitHub Releases (recommended for large files)

Create a Release on GitHub, upload the three artifacts, then edit
`public/downloads/manifest.json`:

```json
{
  "externalReleaseUrl": "https://github.com/your-org/scripturelive-ai/releases/download/v0.2.0"
}
```

The `/api/download/*` endpoints will 302-redirect to GitHub instead of
streaming local files. In external-host mode the API trusts whatever `size`
and `sha256` values are in the manifest, so run the post-build script
described below before committing.

## Filling in size + SHA-256 on the download page

The `/download` page shows each installer's exact byte size and SHA-256
checksum so administrators can verify they have the genuine file. These
values come from `public/downloads/manifest.json`.

A small post-build script populates them automatically. It runs as the last
step of `pnpm run package`, `pnpm run package:win`, and `pnpm run package:mac`,
but you can also run it on its own:

```bash
cd artifacts/imported-app

# After copying installers into public/downloads/ (Option A above), or
# after electron-builder dropped them in release/, run:
pnpm run downloads:manifest

# In CI (e.g. after `download-artifact` puts the files in ./dist):
node scripts/update-download-manifest.mjs --dir ./dist
```

The script looks for each manifest entry's `filename` in (in order):

1. `artifacts/imported-app/public/downloads/`
2. `artifacts/imported-app/release/` (electron-builder default output dir)
3. `<cwd>/dist/` (the path used by `actions/download-artifact`)
4. Any extra directories passed via `--dir <path>` (repeatable)

For each match it writes back `size` (exact bytes) and `sha256` (lower-case
hex). Entries with no matching file on disk are left untouched, so partially
built releases don't lose previously known hashes.

For Option A the API also recomputes the SHA-256 lazily on first request if
the manifest is missing one (handy when you `cp` an installer into
`public/downloads/` and forget to run the script). For Option B you must run
the script — the API can't compute hashes for files it doesn't have.

### End-to-end verification with `minisign`

The SHA-256 hashes shown on `/download` and inside `SHA256SUMS.txt` are only
trustworthy if the channel that delivered them is. An attacker who compromises
the web host could swap an installer **and** rewrite its hash in the same
request. To close that gap, the release pipeline produces a detached
[minisign](https://jedisct1.github.io/minisign/) signature for both
`manifest.json` and `SHA256SUMS.txt` using a maintainer-held key whose public
half is published out-of-band (in this repo at
`artifacts/imported-app/public/downloads/minisign.pub`, mirrored on the
GitHub README) so admins can verify the chain end-to-end.

Each GitHub Release publishes:

- `manifest.json` + `manifest.json.minisig`
- `SHA256SUMS.txt` + `SHA256SUMS.txt.minisig`
- `*.exe` / `*.dmg` (the installers themselves)

The `/download` page surfaces the signature URLs and a copy-pasteable verify
snippet in its **Verify your download** panel whenever
`externalReleaseUrl` is set in `manifest.json`.

#### One-time setup (maintainers)

1. Generate a keypair on a trusted machine. Either encrypted (recommended) or
   passwordless:

   ```bash
   # encrypted (you will be prompted for a password)
   minisign -G -p scripturelive-minisign.pub -s scripturelive-minisign.key
   # OR passwordless (simpler in CI, no MINISIGN_PASSWORD secret needed)
   minisign -G -W -p scripturelive-minisign.pub -s scripturelive-minisign.key
   ```

2. Commit **only the public half** to the repo so `/download` and the README
   can advertise it:

   ```bash
   cp scripturelive-minisign.pub artifacts/imported-app/public/downloads/minisign.pub
   ```

   Also paste the `minisign.pub` contents into the project's GitHub README so
   security-conscious admins have a second, independent copy to cross-check
   the fingerprint against.

3. Base64-encode the **private** key and add it as a repo secret:

   ```bash
   base64 -w 0 scripturelive-minisign.key   # → contents go into MINISIGN_KEY
   ```

   Add `MINISIGN_KEY` (and `MINISIGN_PASSWORD` if you generated an encrypted
   key) under **Settings → Secrets and variables → Actions**. Store the raw
   `.key` file in a password manager — losing it means rotating the public key
   and asking users to re-trust the new one.

#### How users verify

```bash
# install minisign once: brew install minisign  /  apt install minisign
# (Windows users: scoop install minisign)

# fetch from the GitHub Release for the version you downloaded
curl -O https://github.com/<org>/<repo>/releases/download/v0.2.0/manifest.json
curl -O https://github.com/<org>/<repo>/releases/download/v0.2.0/manifest.json.minisig
curl -O https://github.com/<org>/<repo>/releases/download/v0.2.0/SHA256SUMS.txt
curl -O https://github.com/<org>/<repo>/releases/download/v0.2.0/SHA256SUMS.txt.minisig
curl -O https://your-host/downloads/minisign.pub   # cross-check vs README

minisign -Vm manifest.json -p minisign.pub
minisign -Vm SHA256SUMS.txt -p minisign.pub
sha256sum -c SHA256SUMS.txt
```

If `MINISIGN_KEY` is unset, the release still publishes — just without the
`.minisig` sidecars (mirrors the unsigned-installer fallback for `CSC_LINK`).
The build job logs a `::notice::` so this is visible without breaking the
release.

### Bulk verification with `SHA256SUMS.txt`

Admins rolling out the installers to a fleet usually want to verify several
files at once instead of copy-pasting hashes from the page. The `/download`
page shows a **Download SHA256SUMS.txt** link in the *Verify your download*
panel that hits a small generated route:

- `GET /api/download/checksums` → `text/plain` attachment named
  `SHA256SUMS.txt`, in the standard `<sha256>  <filename>` format that
  `sha256sum -c` expects (two spaces, one entry per line).
- In Option A (local host) the route walks the files actually present in
  `public/downloads/` and computes hashes from disk, memoizing each result
  by path+size+mtime so unchanged files are hashed at most once per process.
- In Option B (external host, e.g. GitHub Releases) the route trusts the
  hashes already in `manifest.json` — make sure you ran
  `pnpm run downloads:manifest` against the built artifacts before
  committing.

Workflow on the receiving machine:

```bash
# Download all three installers + the checksums file into the same folder
curl -O https://your-host/api/download/win-x64
curl -O https://your-host/api/download/mac-arm64
curl -O https://your-host/api/download/mac-x64
curl -O https://your-host/api/download/checksums  # → SHA256SUMS.txt

sha256sum -c SHA256SUMS.txt   # Linux / Git-Bash on Windows
shasum -a 256 -c SHA256SUMS.txt   # macOS
```

Lines for installers that aren't on disk yet are omitted (with a `# Note:`
comment in the header listing the missing filenames) so partially built
releases still produce a valid checksum file for whatever is available.

## First-run notes

- **Windows**: a signed installer (Authenticode) installs cleanly. An unsigned installer triggers SmartScreen — click "More info" → "Run anyway".
- **macOS**: a signed + notarized DMG opens directly. An unsigned DMG is blocked by Gatekeeper — right-click the app → **Open**, then confirm.
- Both: ensure your firewall allows the app on the local network — NDI uses mDNS for discovery and TCP/UDP between peers on the LAN.

## Code signing & notarization

Signed builds use the standard `electron-builder` env vars, so anything you set
in your shell, your CI, or a `.env` file the build inherits will be picked up
automatically.

### Windows (Authenticode)

Set both env vars before running `pnpm run package:win`:

```bash
# .pfx can be a path on disk, a base64 string, or an https URL
export CSC_LINK="/absolute/path/to/codesign.pfx"
export CSC_KEY_PASSWORD="<pfx password>"

pnpm run package:win
```

Any Authenticode certificate from a recognised CA (DigiCert, Sectigo, SSL.com,
…) works. **EV certificates** clear SmartScreen warnings the first time the
installer runs; standard OV certificates accumulate trust over the first few
hundred downloads.

To verify the result:

```powershell
Get-AuthenticodeSignature ".\release\ScriptureLive AI-0.2.0-Setup-x64.exe"
# Status should report "Valid" with your publisher name.
```

### macOS (Developer ID + Apple notarization)

You need a `Developer ID Application` certificate from your Apple Developer
account (export it from Keychain Access as a `.p12`) and an app-specific
password generated at <https://appleid.apple.com>.

```bash
# Signing identity
export CSC_LINK="/absolute/path/to/developer-id.p12"
export CSC_KEY_PASSWORD="<p12 password>"

# Notarization (notarytool)
export APPLE_ID="you@example.com"
export APPLE_APP_SPECIFIC_PASSWORD="abcd-efgh-ijkl-mnop"
export APPLE_TEAM_ID="ABCDE12345"

pnpm run package:mac
```

What happens during the build:

1. The `.app` bundle is signed with your Developer ID identity, the hardened
   runtime is enabled, and the entitlements at
   `build-resources/entitlements.mac.plist` are applied.
2. The `afterSign` hook (`build-resources/notarize.js`) submits the `.app` to
   Apple's `notarytool` and waits for the verdict (typically 2–10 minutes).
3. On success the notarization ticket is stapled to the `.app` before the DMG
   is packaged. Gatekeeper will then accept the app on first launch with no
   right-click workaround.

If `CSC_LINK` is unset the build still completes — it just produces an
unsigned/un-notarized DMG so local development isn't blocked. **However**, if
`CSC_LINK` is set but any of `APPLE_ID` / `APPLE_APP_SPECIFIC_PASSWORD` /
`APPLE_TEAM_ID` is missing, the build fails fast. This is intentional: a
signed-but-not-notarized DMG would still trigger Gatekeeper warnings on first
launch, defeating the point of paying for a Developer ID certificate.

To verify the result:

```bash
codesign -dv --verbose=4 "release/ScriptureLive AI.app"
spctl -a -vvv --type install "release/ScriptureLive AI-0.2.0-arm64.dmg"
# Should report: source=Notarized Developer ID
```

### Cloud builds (GitHub Actions)

The same env vars are wired up in `.github/workflows/release-desktop.yml`.
Add the certificates as repository secrets — see
`.github/workflows/README.md` for the exact secret names and expected formats.

### Certificate expiry monitoring

Authenticode certificates expire every 1–3 years and Apple Developer ID
certificates every 5 years; the `APPLE_APP_SPECIFIC_PASSWORD` token can also
be revoked at any time. To make sure releases never silently start shipping
unsigned again, a dedicated GitHub Actions workflow
(`.github/workflows/check-cert-expiry.yml`) runs on the 1st of every month
and on every release, warns at 60 days remaining, and fails (sending a
workflow-failure email to repo admins) at 30 days remaining. Step-by-step
rotation instructions for each secret live in
`.github/workflows/README.md` → **Certificate expiry warnings & rotation**.

As a defence-in-depth backstop in case a rotation is missed,
`release-desktop.yml` adds two verification jobs that gate the GitHub
Release:

- A `verify-macos` job (`macos-latest`) mounts every `.dmg`, then runs
  `codesign --verify --deep --strict`, `spctl -a -vvv --type execute`, and
  `xcrun stapler validate` on the bundled `.app` — refusing to publish if
  the bundle is unsigned, rejected by Gatekeeper, or missing a stapled
  notarization ticket.
- The `release` job (`ubuntu-latest`) re-verifies every downloaded `.exe`
  with `osslsigncode verify` against the runner's system CA bundle.

There's an opt-out for intentional dev releases — re-run the workflow with
the `allow_unsigned` input ticked, or include the marker `[unsigned-release]`
in either the annotated tag message or the HEAD commit message. See
`.github/workflows/README.md` → **Defensive signature check at publish time**
for the exact mechanics.

## How NDI is broadcast

1. The desktop app starts the bundled Next.js server on a random local port.
2. When you click **Enable NDI** in Settings, the main process opens a hidden offscreen `BrowserWindow` that loads `/api/output/congregation` at the chosen resolution.
3. Frames from that window are captured at the chosen FPS (BGRA buffers via `webContents.beginFrameSubscription`).
4. Each frame is pushed into the NDI sender (`grandiose` native binding), which broadcasts on the LAN.
5. Any NDI receiver on the same network sees a source named after the **Source Name** field.

## Falling back

If `grandiose` fails to load (NDI runtime not installed, missing SDK at build time, etc.), the **Native NDI Output** panel shows an "NDI runtime not detected" warning and the legacy browser-capture flow remains fully functional from the same Settings page.

## Dev loop

```bash
# terminal 1 — run Next dev as usual
pnpm --filter @workspace/imported-app run dev

# terminal 2 — run the Electron shell pointed at the dev server
pnpm --filter @workspace/imported-app run electron:dev
```
