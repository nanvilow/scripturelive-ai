import { describe, it, expect } from 'vitest'
import { detectCommand, detectCommandChain } from './commands'

// v0.7.19 — Advanced voice command system tests.
//
// The operator's MASTER PROMPT specifies an 8-case "must pass all"
// test set. Each of those is asserted here, plus coverage for:
//   • the new translation/delete/show-verse intents
//   • wake-word ("Media") priority handling
//   • filler-word filtering ("okay", "thank you", "thank you media")
//   • multi-command chaining ("John 3:16, message version, next verse")
//   • anti-false-trigger guards (negating continuations,
//     translation-alias overlap with preaching vocabulary)
//
// Bible-reference parsing and slide dispatch are covered by their own
// suites (reference-engine + speech-provider integration); this file
// is intentionally focused on the parser surface in commands.ts.

describe('detectCommand — operator must-pass test set (v0.7.19)', () => {
  // 1. "Book of John 3:16" — handled downstream by the reference
  //    engine (detectBestReference). This is NOT a voice command, so
  //    the parser must NOT swallow it. We assert null so the
  //    SpeechProvider falls through to the reference engine.
  it('does NOT treat a bare reference-only utterance as a command', () => {
    expect(detectCommand('Book of John 3:16')).toBeNull()
    expect(detectCommand('John 3:16')).toBeNull()
  })

  // 2. "Give me message version" → change_translation: MSG
  it('parses "Give me message version" as change_translation MSG', () => {
    const cmd = detectCommand('Give me message version')
    expect(cmd?.kind).toBe('change_translation')
    expect(cmd?.translation).toBe('MSG')
  })

  // 3. "Next verse" → next_verse
  it('parses "Next verse" as next_verse', () => {
    const cmd = detectCommand('Next verse')
    expect(cmd?.kind).toBe('next_verse')
  })

  // 4. "Show verse 1" → show_verse_n with verseNumber 1
  it('parses "Show verse 1" as show_verse_n N=1', () => {
    const cmd = detectCommand('Show verse 1')
    expect(cmd?.kind).toBe('show_verse_n')
    expect(cmd?.verseNumber).toBe(1)
  })

  // 5. "In the beginning was the Word" — partial verse text. Not a
  //    command; handled by the text-search / semantic-match path
  //    downstream. Parser must return null.
  it('does NOT treat partial verse text as a command', () => {
    expect(detectCommand('In the beginning was the Word')).toBeNull()
  })

  // 6. "New King James version" → change_translation: NKJV
  //    Critical: must outrank the substring "King James" → KJV
  //    because the alias matcher walks longest-first.
  it('parses "New King James version" as change_translation NKJV (not KJV)', () => {
    const cmd = detectCommand('New King James version')
    expect(cmd?.kind).toBe('change_translation')
    expect(cmd?.translation).toBe('NKJV')
  })

  // 7. "Media, delete previous verse" → wake-word + delete_previous_verse
  it('parses "Media, delete previous verse" as delete_previous_verse with wake word', () => {
    const cmd = detectCommand('Media, delete previous verse')
    expect(cmd?.kind).toBe('delete_previous_verse')
    expect(cmd?.wakeWord).toBe(true)
  })

  // 8. "Media, clear screen" → wake-word + clear_screen
  it('parses "Media, clear screen" as clear_screen with wake word', () => {
    const cmd = detectCommand('Media, clear screen')
    expect(cmd?.kind).toBe('clear_screen')
    expect(cmd?.wakeWord).toBe(true)
  })
})

describe('detectCommand — translation aliases', () => {
  it.each([
    ['Give me KJV', 'KJV'],
    ['Give me King James version', 'KJV'],
    ['Give me NKJV', 'NKJV'],
    ['Give me Amplified', 'AMP'],
    ['Give me amplified version', 'AMP'],
    ['Switch to ESV', 'ESV'],
    ['Change to NIV', 'NIV'],
    ['Use NLT', 'NLT'],
    ['Show me NASB', 'NASB'],
    ['Give me CSB', 'CSB'],
    ['Give me RSV', 'RSV'],
    ['Switch to ASV', 'ASV'],
    ['Use WEB', 'WEB'],
    ['Give me Darby', 'DARBY'],
  ])('"%s" → translation %s', (utterance, expected) => {
    const cmd = detectCommand(utterance)
    expect(cmd?.kind).toBe('change_translation')
    expect(cmd?.translation).toBe(expected)
  })

  // Bare alias alone — should still parse as a translation switch.
  it('"NKJV" alone parses as change_translation NKJV', () => {
    expect(detectCommand('NKJV')?.translation).toBe('NKJV')
  })
  it('"the message" alone parses as change_translation MSG', () => {
    expect(detectCommand('the message')?.translation).toBe('MSG')
  })
})

describe('detectCommand — anti-false-trigger guards', () => {
  // The translation aliases overlap with common preaching vocab.
  // Without strict-mode gating, "the message of the cross" would
  // accidentally switch to MSG. Guard: bare-alias mode requires the
  // utterance to be JUST the alias (+ optional version/bible suffix).
  it('does NOT switch translation on "the message of the cross"', () => {
    expect(detectCommand('the message of the cross')).toBeNull()
  })

  it('does NOT switch translation on "amplified by his grace"', () => {
    expect(detectCommand('amplified by his grace')).toBeNull()
  })

  // Negating continuation: "next verse says ..." is the preacher
  // reading, not a navigation command.
  it('does NOT trigger next_verse on "next verse says love your neighbor"', () => {
    expect(detectCommand('next verse says love your neighbor')).toBeNull()
  })
})

describe('detectCommand — filler-word filter', () => {
  it.each([
    'okay',
    'OK',
    'thank you',
    'thanks',
    'thank you media',
    'very good',
    'amen',
    'praise God',
    'Hallelujah',
    'mm',
  ])('"%s" returns null (filler)', (utterance) => {
    expect(detectCommand(utterance)).toBeNull()
  })

  // "Media, okay" — wake word followed by filler. Must still be null
  // so we don't try to dispatch an empty command.
  it('"Media, okay" returns null (wake word + filler)', () => {
    expect(detectCommand('Media, okay')).toBeNull()
  })
})

describe('detectCommand — wake-word handling', () => {
  it('strips "Media, " prefix and recognises the underlying command', () => {
    const cmd = detectCommand('Media, next verse')
    expect(cmd?.kind).toBe('next_verse')
    expect(cmd?.wakeWord).toBe(true)
  })

  it('strips "Media: " prefix', () => {
    const cmd = detectCommand('Media: clear screen')
    expect(cmd?.kind).toBe('clear_screen')
    expect(cmd?.wakeWord).toBe(true)
  })

  it('strips "Hey media " prefix', () => {
    const cmd = detectCommand('Hey media next verse')
    expect(cmd?.kind).toBe('next_verse')
    expect(cmd?.wakeWord).toBe(true)
  })

  it('wake word gives higher confidence than the same command without it', () => {
    const wokeCmd = detectCommand('Media, next verse')
    const bareCmd = detectCommand('Next verse')
    expect(wokeCmd?.confidence ?? 0).toBeGreaterThan(bareCmd?.confidence ?? 0)
  })

  it('wake word allows a longer courtesy tail ("media clear screen now thanks")', () => {
    // Without the wake word, the post-trigger tail "now thanks" would
    // exceed the 12-char heuristic and reject. With it, we accept up
    // to 24 chars of tail.
    const woke = detectCommand('Media, clear screen now thanks')
    expect(woke?.kind).toBe('clear_screen')
    const bare = detectCommand('clear screen now thanks please')
    expect(bare).toBeNull()
  })
})

describe('detectCommand — show_verse_n', () => {
  it.each([
    ['Show verse 1', 1],
    ['Go to verse 7', 7],
    ['Display verse 23', 23],
    ['Jump to verse 16', 16],
    ['Read verse 3', 3],
    // v0.7.116 — Massively expanded triggers per operator request:
    // "Add 'let go to verse...', 'take me to verse...', 'scroll down
    // to verse...' etc."
    ["Let's go to verse 5", 5],
    ['Lets go to verse 5', 5],
    ['Let go to verse 5', 5],
    ['Take me to verse 12', 12],
    ['Scroll down to verse 4', 4],
    ['Scroll up to verse 8', 8],
    ['Go down to verse 9', 9],
    ['Go up to verse 2', 2],
    ['Move to verse 6', 6],
    ['Move down to verse 11', 11],
    ['Skip to verse 14', 14],
    ['Skip down to verse 17', 17],
    ['Turn to verse 21', 21],
  ])('"%s" → verseNumber %d', (utterance, n) => {
    const cmd = detectCommand(utterance)
    expect(cmd?.kind).toBe('show_verse_n')
    expect(cmd?.verseNumber).toBe(n)
  })

  it('"verse 5" alone (without wake word) still parses', () => {
    const cmd = detectCommand('verse 5')
    expect(cmd?.kind).toBe('show_verse_n')
    expect(cmd?.verseNumber).toBe(5)
  })

  it('rejects out-of-range verse numbers', () => {
    expect(detectCommand('show verse 9999')).toBeNull()
  })
})

describe('detectCommand — delete_previous_verse', () => {
  it.each([
    'delete previous verse',
    'delete previous bars',
    'remove previous verse',
    'delete that verse',
    'remove last verse',
    'undo last verse',
    'remove that scripture',
  ])('"%s" → delete_previous_verse', (utterance) => {
    expect(detectCommand(utterance)?.kind).toBe('delete_previous_verse')
  })
})

describe('detectCommandChain — multi-command chaining', () => {
  it('parses "John 3:16, message version, next verse" as 3 commands', () => {
    const chain = detectCommandChain('John 3:16, message version, next verse')
    expect(chain.length).toBe(3)
    expect(chain[0]?.kind).toBe('go_to_reference')
    expect(chain[0]?.reference?.book).toBe('John')
    expect(chain[0]?.reference?.chapter).toBe(3)
    expect(chain[0]?.reference?.verseStart).toBe(16)
    expect(chain[1]?.kind).toBe('change_translation')
    expect(chain[1]?.translation).toBe('MSG')
    expect(chain[2]?.kind).toBe('next_verse')
  })

  it('parses "Media, NKJV, clear screen" with wake-word propagation', () => {
    const chain = detectCommandChain('Media, NKJV, clear screen')
    expect(chain.length).toBe(2)
    expect(chain[0]?.kind).toBe('change_translation')
    expect(chain[0]?.translation).toBe('NKJV')
    expect(chain[0]?.wakeWord).toBe(true)
    expect(chain[1]?.kind).toBe('clear_screen')
    expect(chain[1]?.wakeWord).toBe(true)
  })

  it('"and then" / "then" separator works', () => {
    const chain = detectCommandChain('next verse then previous verse')
    expect(chain.length).toBe(2)
    expect(chain[0]?.kind).toBe('next_verse')
    expect(chain[1]?.kind).toBe('previous_verse')
  })

  it('returns single command for non-chained utterance', () => {
    const chain = detectCommandChain('next verse')
    expect(chain.length).toBe(1)
    expect(chain[0]?.kind).toBe('next_verse')
  })

  it('returns empty array for filler', () => {
    expect(detectCommandChain('okay, thank you, very good')).toEqual([])
  })
})

// ── v0.7.23 — AI Verse Search detector ────────────────────────────────
// v0.7.110 — chapter navigation. v0.7.78 had hijacked "next chapter"
// → next_verse (one-verse step). The current operator wants real
// chapter jumps; the dispatcher case has always existed.
describe('detectCommand — chapter navigation (v0.7.110)', () => {
  it('"next chapter" → next_chapter (NOT next_verse)', () => {
    const c = detectCommand('next chapter')
    expect(c?.kind).toBe('next_chapter')
  })

  it('"previous chapter" → previous_chapter', () => {
    const c = detectCommand('previous chapter')
    expect(c?.kind).toBe('previous_chapter')
  })

  it('"prev chapter" → previous_chapter', () => {
    const c = detectCommand('prev chapter')
    expect(c?.kind).toBe('previous_chapter')
  })

  it('"Media, next chapter" → next_chapter with wake word', () => {
    const c = detectCommand('Media, next chapter')
    expect(c?.kind).toBe('next_chapter')
    expect(c?.wakeWord).toBe(true)
  })

  it('"next verse" still routes to next_verse (one-verse step preserved)', () => {
    const c = detectCommand('next verse')
    expect(c?.kind).toBe('next_verse')
  })
})

describe('detectCommand — find_by_quote (AI Verse Search)', () => {
  it('"find the verse about loving your enemies" → find_by_quote', () => {
    const c = detectCommand('find the verse about loving your enemies')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('loving your enemies')
    expect(c?.confidence).toBeGreaterThanOrEqual(80)
  })

  it('"find that scripture about being born again" works', () => {
    const c = detectCommand('find that scripture about being born again')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('being born again')
  })

  it('"find me the verse about faith" works', () => {
    const c = detectCommand('find me the verse about faith')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('faith')
  })

  it('"what is the verse that says love is patient" works', () => {
    const c = detectCommand('what is the verse that says love is patient')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('love is patient')
  })

  it("\"what's the scripture about the city on a hill\" works", () => {
    const c = detectCommand("what's the scripture about the city on a hill")
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('the city on a hill')
  })

  it('"the verse about loving your neighbor" works', () => {
    const c = detectCommand('the verse about loving your neighbor')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('loving your neighbor')
  })

  it('"where does the bible say be still and know" works', () => {
    const c = detectCommand('where does the bible say be still and know')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('be still and know')
  })

  it('"which verse talks about love" works', () => {
    const c = detectCommand('which verse talks about love')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('love')
  })

  it('"show me the verse about prayer" works', () => {
    const c = detectCommand('show me the verse about prayer')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('prayer')
  })

  // v0.7.110 — Natural Bible-question patterns. Pre-110 these all
  // returned null because the regex required the literal word
  // "verse" / "scripture" / "passage" — production complaint:
  // "doesn't answer Bible questions".
  it('"show me where Jesus wept" → find_by_quote (natural question)', () => {
    const c = detectCommand('show me where Jesus wept')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('Jesus wept')
  })

  it('"where did they say silver and gold have I none" → find_by_quote', () => {
    const c = detectCommand('where did they say silver and gold have I none')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('they say silver and gold have I none')
  })

  it('"where was Stephen stoned to death" → find_by_quote', () => {
    const c = detectCommand('where was Stephen stoned to death')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('Stephen stoned to death')
  })

  it('"where did Jesus weep" → find_by_quote', () => {
    const c = detectCommand('where did Jesus weep')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('Jesus weep')
  })

  it('"who said love your enemies" → find_by_quote', () => {
    const c = detectCommand('who said love your enemies')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('love your enemies')
  })

  it('"what did Jesus say about prayer" → find_by_quote (group 2 capture)', () => {
    const c = detectCommand('what did Jesus say about prayer')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('prayer')
  })

  it('with wake word "Media, the verse about grace" works', () => {
    const c = detectCommand('Media, the verse about grace')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('grace')
    expect(c?.wakeWord).toBe(true)
  })

  it('with wake word, bare "verse about love" form works', () => {
    const c = detectCommand('Media, verse about love')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('love')
    expect(c?.wakeWord).toBe(true)
  })

  it('without wake word, bare "verse about love" does NOT match', () => {
    const c = detectCommand('verse about love')
    expect(c?.kind).not.toBe('find_by_quote')
  })

  it('strips trailing "please" from quote', () => {
    const c = detectCommand('find the verse about love please')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('love')
  })

  it('strips trailing punctuation', () => {
    const c = detectCommand('find the verse about hope.')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('hope')
  })

  it('rejects too-short quote', () => {
    const c = detectCommand('find the verse about it')
    expect(c?.kind).not.toBe('find_by_quote')
  })

  it('does NOT misfire on "find john 3:16"', () => {
    // Operator said an explicit reference — should NOT be quote search.
    // (It also won't match find_by_quote because there's no "verse"/"scripture" keyword.)
    const c = detectCommand('find john 3 16')
    expect(c?.kind).not.toBe('find_by_quote')
  })

  it('does NOT misfire on plain "next verse"', () => {
    const c = detectCommand('next verse')
    expect(c?.kind).toBe('next_verse')
  })

  // v0.7.113 — Trailing-punctuation regression. Pre-113 the strict
  // trigger comparison failed when ASR appended a period/comma to the
  // final chunk, so "next chapter." silently routed through the
  // next_verse pattern (bare "next" + tail "chapter."). These tests
  // pin the trailing-punct strip behaviour so the regression can't
  // come back.
  it('next chapter with trailing period fires next_chapter', () => {
    expect(detectCommand('next chapter.')?.kind).toBe('next_chapter')
    expect(detectCommand('Next chapter.')?.kind).toBe('next_chapter')
    expect(detectCommand('next chapter,')?.kind).toBe('next_chapter')
    expect(detectCommand('next chapter?')?.kind).toBe('next_chapter')
  })
  it('previous chapter with trailing period fires previous_chapter', () => {
    expect(detectCommand('previous chapter.')?.kind).toBe('previous_chapter')
    expect(detectCommand('previous chapter,')?.kind).toBe('previous_chapter')
  })
  it('verse N with trailing period fires show_verse_n', () => {
    const c = detectCommand('verse 10.')
    expect(c?.kind).toBe('show_verse_n')
    expect(c?.verseNumber).toBe(10)
  })
  it('show verse N with trailing period fires show_verse_n', () => {
    const c = detectCommand('show verse 5.')
    expect(c?.kind).toBe('show_verse_n')
    expect(c?.verseNumber).toBe(5)
  })
  it('next verse with trailing period still fires next_verse (not regressed)', () => {
    expect(detectCommand('next verse.')?.kind).toBe('next_verse')
  })

  it('does NOT misfire on "show verse 16"', () => {
    // Existing show_verse_n behaviour must still win.
    const c = detectCommand('show verse 16')
    expect(c?.kind).toBe('show_verse_n')
    expect(c?.verseNumber).toBe(16)
  })

  it('caps a runaway long quote at 240 chars', () => {
    const long = 'love '.repeat(80) // 400 chars
    const c = detectCommand(`find the verse about ${long}`)
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText?.length).toBeLessThanOrEqual(240)
  })

  it('label preview is reasonable', () => {
    const c = detectCommand('find the verse about loving your enemies')
    expect(c?.label).toMatch(/^Find: /)
  })
})

// ── v0.7.111 — "in the bible" prefix strip ───────────────────────
//
// Operator complaint after v0.7.110: "Show me where in the bible
// Jesus was crucified" matched the new natural-question pattern but
// captured "in the bible Jesus was crucified" as the quote, which
// the semantic matcher couldn't resolve. Now the leading "in (the)
// bible / scripture / scriptures / word (of god)" is stripped so the
// search runs against the actual subject.
describe('detectCommand — find_by_quote v0.7.111 prefix strip', () => {
  it('"show me where in the bible Jesus was crucified" → quote = "Jesus was crucified"', () => {
    const c = detectCommand('show me where in the bible Jesus was crucified')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('Jesus was crucified')
  })

  it('"where did in the bible David fight Goliath" strips "in the bible"', () => {
    const c = detectCommand('where did in the bible David fight Goliath')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('David fight Goliath')
  })

  it('"show me where in scripture Stephen was stoned" strips "in scripture"', () => {
    const c = detectCommand('show me where in scripture Stephen was stoned')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('Stephen was stoned')
  })

  it('"show me where in the scriptures Moses parted the sea" strips "in the scriptures"', () => {
    const c = detectCommand('show me where in the scriptures Moses parted the sea')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('Moses parted the sea')
  })

  it('"show me where in the word of god love is patient" strips "in the word of god"', () => {
    const c = detectCommand('show me where in the word of god love is patient')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toBe('love is patient')
  })

  it('label no longer leaks the "in the bible" prefix', () => {
    const c = detectCommand('show me where in the bible Jesus wept')
    expect(c?.label).not.toMatch(/in the bible/i)
    expect(c?.label).toMatch(/Jesus wept/i)
  })

  it('strip is anchored to the START — internal "in the bible" survives', () => {
    // We only strip a leading prefix; an internal "the bible" must
    // be preserved so questions like "what does the bible mean by
    // grace" are not silently mangled if they reach this matcher.
    const c = detectCommand('show me where the bible mentions grace')
    expect(c?.kind).toBe('find_by_quote')
    expect(c?.quoteText).toContain('bible')
  })
})
