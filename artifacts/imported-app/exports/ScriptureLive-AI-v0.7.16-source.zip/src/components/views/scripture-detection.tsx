'use client'

import { useState, useRef, useCallback, useEffect } from 'react'
import { useAppStore, type DetectedVerse } from '@/lib/store'
import { detectVersesInText, fetchBibleVerse } from '@/lib/bible-api'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { ScrollArea } from '@/components/ui/scroll-area'
import {
  Mic,
  MicOff,
  BookOpen,
  AlertCircle,
  Volume2,
  Clock,
  Trash2,
  Maximize2,
  Send,
  Type,
  Info,
  Zap,
  RotateCcw,
  Sparkles,
} from 'lucide-react'
import { cn } from '@/lib/utils'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'

export function ScriptureDetectionView() {
  // ── Read ALL speech state from the store (managed by SpeechProvider) ──
  const {
    isListening,
    liveTranscript,
    liveInterimTranscript,
    speechSupported,
    speechError,
    setSpeechCommand,
    detectedVerses,
    addDetectedVerse,
    clearDetectedVerses,
    liveVerse,
    setLiveVerse,
    selectedTranslation,
    addToVerseHistory,
    setSlides,
    setPreviewSlideIndex,
    setLiveSlideIndex,
    setIsLive,
    slides,
    settings,
    updateSettings,
  } = useAppStore()
  // v0.5.30 — share the same Bible-only filter used by the operator
  // shell. When ON, the Live Transcript card on this view shows only
  // the sentences that contain a Bible reference, so an hour-long
  // sermon doesn't bury the verse callouts in unrelated chatter.
  const bibleOnlyTranscription = useAppStore((s) => s.bibleOnlyTranscription)
  const setBibleOnlyTranscription = useAppStore((s) => s.setBibleOnlyTranscription)
  // Pre-compute the Bible-filtered transcript by splitting on
  // sentence boundaries and keeping only sentences that detect a
  // verse. Cheap enough to run inline (transcripts max out around
  // 10 KB before the speech provider rolls them).
  const filteredTranscript = (() => {
    if (!bibleOnlyTranscription) return liveTranscript
    if (!liveTranscript) return ''
    const sentences = liveTranscript
      .split(/(?<=[.!?])\s+|\n+/)
      .map((s) => s.trim())
      .filter(Boolean)
    return sentences.filter((s) => detectVersesInText(s).length > 0).join(' ')
  })()

  const processedRefsRef = useRef<Set<string>>(new Set())
  const [isFullscreen, setIsFullscreen] = useState(false)
  const liveDisplayRef = useRef<HTMLDivElement>(null)
  const [manualInput, setManualInput] = useState('')

  // v0.6.0 — AI semantic match feedback. When the operator says
  // something that PARAPHRASES a popular verse without naming the
  // reference (e.g. "the Lord is my shepherd I shall not want")
  // we surface the top semantic candidate as a suggestion chip
  // beneath the live transcript. They click to send it live —
  // no more missing the verse just because the regex matcher needs
  // a "Book chap:verse" token to trigger.
  const [aiSuggestion, setAiSuggestion] = useState<{
    reference: string
    text: string
    score: number
    confidence: 'high' | 'medium' | 'low'
  } | null>(null)
  const aiBusyRef = useRef<boolean>(false)
  const lastSemanticPhraseRef = useRef<string>('')
  const semanticWarmedRef = useRef<boolean>(false)

  // Warm the embedding cache the first time the operator hits the
  // detection page WHILE listening — the cache lives in the Next.js
  // worker so this is a one-time ~250 ms cost paid up front instead
  // of stalling the operator's first transcript phrase by 250 ms.
  useEffect(() => {
    if (semanticWarmedRef.current) return
    if (!isListening) return
    semanticWarmedRef.current = true
    fetch('/api/scripture/semantic-match', { method: 'GET' }).catch(() => {
      // Silent — falls through to regex matcher when the API is unreachable.
    })
  }, [isListening])

  // Watch the live transcript and run the AI semantic matcher on
  // each new committed sentence. We debounce to ~600 ms after the
  // last update so we don't fire one embedding per word.
  useEffect(() => {
    // Stop-listening or empty transcript: drop any stale AI chip so
    // the operator never sees a dangling suggestion from a previous
    // session / utterance.
    if (!isListening || !liveTranscript) {
      lastSemanticPhraseRef.current = ''
      setAiSuggestion(null)
      return
    }
    // Take the LAST sentence (split on punctuation/newline).
    const sentences = liveTranscript
      .split(/(?<=[.!?])\s+|\n+/)
      .map((s) => s.trim())
      .filter((s) => s.length >= 12)
    const phrase = sentences[sentences.length - 1] ?? ''
    if (!phrase) return
    if (phrase === lastSemanticPhraseRef.current) return
    // If the regex matcher already finds a verse in this phrase,
    // skip the embedding call AND clear any stale AI chip — regex
    // matches carry the operator's own translation pick and are
    // strictly preferred, so the chip must yield to them.
    if (detectVersesInText(phrase).length > 0) {
      lastSemanticPhraseRef.current = phrase
      setAiSuggestion(null)
      return
    }
    const handle = setTimeout(async () => {
      if (aiBusyRef.current) return
      aiBusyRef.current = true
      lastSemanticPhraseRef.current = phrase
      try {
        const r = await fetch('/api/scripture/semantic-match', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: phrase, topK: 1 }),
        })
        if (!r.ok) return
        const j = await r.json()
        const top = (j.matches as Array<{
          reference: string
          text: string
          score: number
          confidence: 'high' | 'medium' | 'low'
        }> | undefined)?.[0]
        if (!top) {
          setAiSuggestion(null)
          return
        }
        setAiSuggestion(top)
      } catch {
        /* swallow — falls through to regex-only behaviour */
      } finally {
        aiBusyRef.current = false
      }
    }, 600)
    return () => clearTimeout(handle)
  }, [liveTranscript, isListening])

  // Send an AI-suggested verse live. Re-fetches the verse in the
  // operator's currently-selected translation so a paraphrased KJV
  // match still respects their NIV/ESV/etc. preference.
  // v0.6.4 — Track which AI suggestion reference we've already
  // auto-fired in this session so the auto-send effect doesn't loop
  // (sendAiSuggestionLive nulls aiSuggestion, but a new transcript
  // tick could resurface the same match before the operator speaks
  // anything new). We reset this ref whenever the operator stops
  // listening so a new sermon starts with a clean slate.
  const lastAutoSentRef = useRef<string | null>(null)

  const sendAiSuggestionLive = useCallback(async () => {
    if (!aiSuggestion) return
    try {
      const fetched = await fetchBibleVerse(aiSuggestion.reference, selectedTranslation)
      if (fetched) {
        setLiveVerse(fetched)
        addToVerseHistory(fetched)
        toast.success(`AI sent ${aiSuggestion.reference} live`)
      } else {
        // Fall back to the KJV text the matcher returned so the
        // operator never gets a dead click.
        setLiveVerse({
          reference: aiSuggestion.reference,
          text: aiSuggestion.text,
          translation: 'KJV',
          book: '',
          chapter: 0,
          verseStart: 0,
        })
        toast.success(`AI sent ${aiSuggestion.reference} live (KJV fallback)`)
      }
      setAiSuggestion(null)
    } catch {
      toast.error('Failed to send AI suggestion')
    }
  }, [aiSuggestion, selectedTranslation, setLiveVerse, addToVerseHistory])

  // v0.6.4 — Auto-fire HIGH-confidence semantic matches the moment
  // they land, IF the operator has both Auto Go-Live and AI Auto-Send
  // enabled. This is the missing piece operators reported as "smart
  // detection not working" in v0.6.3 — the matcher already returned
  // 0.81 for the failing example, but the suggestion chip just sat
  // there waiting for a click. Now it pushes live with the same one-
  // shot guard the regex path already uses (lastAutoSentRef).
  useEffect(() => {
    if (!aiSuggestion) return
    if (aiSuggestion.confidence !== 'high') return
    if (!settings.autoGoLiveOnDetection) return
    if (!settings.aiAutoSendOnHigh) return
    // De-dupe: don't auto-fire the same reference twice in a row even
    // if the matcher resurfaces it on the next transcript tick.
    if (lastAutoSentRef.current === aiSuggestion.reference) return
    lastAutoSentRef.current = aiSuggestion.reference
    sendAiSuggestionLive()
  }, [aiSuggestion, settings.autoGoLiveOnDetection, settings.aiAutoSendOnHigh, sendAiSuggestionLive])

  // Reset the AI auto-send dedupe ring whenever the operator stops
  // listening so the next sermon starts with a clean slate (otherwise
  // the same verse spoken twice across services wouldn't auto-fire).
  useEffect(() => {
    if (!isListening) lastAutoSentRef.current = null
  }, [isListening])

  // ── Go Live with a verse ─────────────────────────────────────────────
  const goLiveWithVerse = useCallback((
    verseOrRef: DetectedVerse | { reference: string; text: string; translation: string },
    navigateToPresenter = false,
  ) => {
    const state = useAppStore.getState()
    const slide = {
      id: `slide-${Date.now()}`,
      type: 'verse' as const,
      title: verseOrRef.reference,
      subtitle: verseOrRef.translation,
      content: verseOrRef.text.split('\n').filter(Boolean),
      background: state.settings.congregationScreenTheme,
    }
    const currentSlides = state.slides.length > 0 ? [...state.slides, slide] : [slide]
    const newLiveIndex = currentSlides.length - 1

    state.setSlides(currentSlides)
    state.setPreviewSlideIndex(newLiveIndex)
    state.setLiveSlideIndex(newLiveIndex)
    state.setIsLive(true)

    // Only navigate to presenter when explicitly requested (manual "Go Live" button)
    if (navigateToPresenter) {
      useAppStore.getState().setCurrentView('presenter')
    }

    // Suppressed per FRS — live pill is the source of truth.
  }, [])

  // ── Manual verse detection from text input ───────────────────────────
  const handleManualDetect = useCallback(async () => {
    if (!manualInput.trim()) return

    const text = manualInput.trim()
    const references = detectVersesInText(text)
    let foundAny = false

    for (const ref of references) {
      if (processedRefsRef.current.has(ref)) continue
      processedRefsRef.current = new Set(processedRefsRef.current).add(ref)

      try {
        const verse = await fetchBibleVerse(ref, selectedTranslation)
        if (verse) {
          foundAny = true
          const detected: DetectedVerse = {
            id: `det-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            reference: ref,
            text: verse.text,
            translation: selectedTranslation,
            detectedAt: new Date(),
            confidence: 0.9,
          }
          addDetectedVerse(detected)
          setLiveVerse(verse)
          addToVerseHistory(verse)
          // Suppressed per FRS — Detected Verses panel is the source of truth.

          if (settings.autoGoLiveOnDetection) {
            goLiveWithVerse(detected)
          }
        }
      } catch {
        // Silently ignore
      }
    }

    if (!foundAny) {
      toast.info('No Bible references detected in the text')
    }
    setManualInput('')
  }, [manualInput, selectedTranslation, addDetectedVerse, setLiveVerse, addToVerseHistory, settings.autoGoLiveOnDetection, goLiveWithVerse])

  // ── Toggle listening via store command ───────────────────────────────
  const toggleListening = () => {
    if (isListening) {
      setSpeechCommand('stop')
    } else {
      processedRefsRef.current = new Set()
      setSpeechCommand('start')
    }
  }

  // ── Reset transcript ────────────────────────────────────────────────
  const handleReset = () => {
    setSpeechCommand('reset')
  }

  // ── Fullscreen toggle ───────────────────────────────────────────────
  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      liveDisplayRef.current?.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  return (
    <div className="flex h-full flex-col lg:flex-row">
      {/* Main Detection Panel */}
      <div className="flex-1 flex flex-col p-4 md:p-6 lg:p-8 overflow-y-auto">
        {/* Top Controls */}
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-foreground">Live Scripture Detection</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              Detects Bible references from speech or text input
              {isListening && (
                <span className="text-emerald-400 ml-1.5 font-medium">
                  — Active in background
                </span>
              )}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {/* Auto Go-Live Toggle */}
            <button
              onClick={() => updateSettings({ autoGoLiveOnDetection: !settings.autoGoLiveOnDetection })}
              className={cn(
                'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all border',
                settings.autoGoLiveOnDetection
                  ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
                  : 'bg-muted border-border text-muted-foreground hover:bg-muted/80',
              )}
            >
              <Zap className={cn('h-3.5 w-3.5', settings.autoGoLiveOnDetection && 'text-emerald-400')} />
              Auto Go-Live
            </button>
            {/* v0.6.4 — AI Auto-Send. Only shown when Auto Go-Live is
                on (it's a child option). When ON, HIGH-confidence
                semantic matches push live without an operator click. */}
            {settings.autoGoLiveOnDetection && (
              <button
                onClick={() => updateSettings({ aiAutoSendOnHigh: !settings.aiAutoSendOnHigh })}
                title={
                  settings.aiAutoSendOnHigh
                    ? 'AI auto-send: HIGH-confidence semantic matches push live automatically'
                    : 'AI auto-send disabled — high-confidence matches still surface as a suggestion chip'
                }
                className={cn(
                  'flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all border',
                  settings.aiAutoSendOnHigh
                    ? 'bg-violet-500/15 border-violet-500/30 text-violet-300'
                    : 'bg-muted border-border text-muted-foreground hover:bg-muted/80',
                )}
              >
                <Sparkles className={cn('h-3.5 w-3.5', settings.aiAutoSendOnHigh && 'text-violet-300')} />
                AI Auto-Send
              </button>
            )}
            {liveTranscript && (
              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1" onClick={handleReset}>
                <RotateCcw className="h-3 w-3" />
                Reset
              </Button>
            )}
          </div>
        </div>

        {/* Mic Button */}
        <div className="flex flex-col items-center mb-6">
          <button
            onClick={toggleListening}
            className={cn(
              'relative flex h-20 w-20 items-center justify-center rounded-full transition-all duration-300',
              isListening
                ? 'bg-red-500/20 shadow-[0_0_40px_rgba(239,68,68,0.3)] hover:bg-red-500/30'
                : 'bg-primary/15 shadow-[0_0_40px_rgba(234,179,8,0.1)] hover:bg-primary/25',
            )}
          >
            {isListening && (
              <span className="absolute inset-0 rounded-full border-2 border-red-500/50 animate-ping pointer-events-none" />
            )}
            {isListening ? (
              <MicOff className="h-9 w-9 text-red-400" />
            ) : (
              <Mic className="h-9 w-9 text-primary" />
            )}
          </button>
          <p className="mt-3 text-sm font-medium text-foreground">
            {isListening ? 'Listening for Bible verses...' : 'Tap to start listening'}
          </p>
          {isListening && (
            <div className="flex items-center gap-1.5 mt-2">
              <Badge variant="destructive" className="gap-1.5">
                <span className="live-indicator inline-block h-2 w-2 rounded-full bg-white" />
                LIVE
              </Badge>
              <span className="text-[10px] text-muted-foreground">Runs in background</span>
            </div>
          )}
        </div>

        {/* Manual Input Fallback */}
        <Card className="mb-6 border-border/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Type className="h-4 w-4 text-muted-foreground" />
              <span className="text-xs font-medium text-muted-foreground">Or type/paste text to detect verses</span>
            </div>
            <div className="flex gap-2">
              <Input
                placeholder='Paste sermon text here... (e.g. "Turn to Romans 8:28")'
                value={manualInput}
                onChange={(e) => setManualInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleManualDetect()}
                className="flex-1 h-9 bg-card border-border text-sm"
              />
              <Button onClick={handleManualDetect} size="sm" className="h-9 gap-1.5">
                <BookOpen className="h-3.5 w-3.5" />
                Detect
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Browser Not Supported */}
        {!speechSupported && (
          <Card className="mb-4 border-amber-500/30 bg-amber-500/5">
            <CardContent className="flex items-start gap-3 p-4">
              <AlertCircle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-amber-300">Browser Not Supported</p>
                <p className="text-xs text-amber-400/70 mt-1">
                  Speech recognition requires Google Chrome or Microsoft Edge. Use the manual text input above as an alternative.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Speech Error Messages */}
        {speechError && (
          <Card className="mb-4 border-destructive/30 bg-destructive/5">
            <CardContent className="flex items-start gap-3 p-4">
              <AlertCircle className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
              <div>
                <p className="text-sm text-destructive">{speechError}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Try the manual text input above as an alternative to speech detection.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Info about background listening */}
        <Card className="mb-6 border-blue-500/20 bg-blue-500/5">
          <CardContent className="flex items-start gap-3 p-3">
            <Info className="h-4 w-4 text-blue-400 shrink-0 mt-0.5" />
            <p className="text-xs text-blue-300/70 leading-relaxed">
              Speech recognition runs <strong>continuously in the background</strong> — it won&apos;t stop when you switch pages, minimize the app, or open another tab.
              Detected verses are automatically sent to Live Presenter when Auto Go-Live is enabled.
              Use <strong>Google Chrome</strong> for best results.
            </p>
          </CardContent>
        </Card>

        {/* Live Transcript - Always visible when listening */}
        <Card className="mb-6 border-border/50">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Volume2 className="h-4 w-4 text-muted-foreground" />
              Live Transcript
              {isListening && <span className="live-indicator inline-block h-2 w-2 rounded-full bg-red-500 animate-pulse" />}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="max-h-48 overflow-y-auto rounded-lg bg-muted/30 p-4 min-h-[60px]">
              {/* v0.5.30 — Bible-only filter pill. Lives on the right
                  of the transcript so the operator can flip between a
                  curated view and the raw stream without leaving the
                  Scripture Detection page. */}
              <div className="flex justify-end mb-1">
                <button
                  type="button"
                  onClick={() => setBibleOnlyTranscription(!bibleOnlyTranscription)}
                  title={
                    bibleOnlyTranscription
                      ? 'Showing only sentences with a Bible reference. Click to show full transcript.'
                      : 'Showing full transcript. Click to filter to Bible references only.'
                  }
                  className={cn(
                    'h-5 px-1.5 rounded text-[9px] uppercase tracking-wider font-semibold border inline-flex items-center gap-1 transition-colors',
                    bibleOnlyTranscription
                      ? 'bg-amber-500/15 text-amber-300 border-amber-500/40 hover:bg-amber-500/25'
                      : 'bg-muted text-muted-foreground border-border hover:text-foreground',
                  )}
                >
                  <BookOpen className="h-2.5 w-2.5" />
                  {bibleOnlyTranscription ? 'Bible-only' : 'All'}
                </button>
              </div>
              {(filteredTranscript || liveInterimTranscript) ? (
                <p className="text-sm text-foreground/80 whitespace-pre-wrap">
                  {filteredTranscript}
                  {/* The interim line is always shown live so the
                      operator can confirm the mic is hearing them; the
                      Bible-only filter operates on committed text only. */}
                  {liveInterimTranscript && (
                    <span className="text-muted-foreground italic"> {liveInterimTranscript}</span>
                  )}
                </p>
              ) : (
                <p className="text-xs text-muted-foreground italic">
                  {isListening
                    ? bibleOnlyTranscription && liveTranscript
                      ? 'Listening… no Bible references heard yet (click "Bible-only" to see all spoken text)'
                      : 'Listening… speak into your microphone'
                    : 'Transcript will appear here when you start listening'}
                </p>
              )}
              {/* v0.6.0 — AI semantic-match suggestion chip. Renders
                  only when the matcher returns a HIGH or MEDIUM
                  confidence candidate that the regex matcher missed.
                  Click to send live (auto re-fetches the verse in the
                  operator's selected translation). */}
              {aiSuggestion && (
                <div className="mt-3 flex items-center gap-2 rounded-md border border-violet-500/30 bg-violet-500/5 px-3 py-2">
                  <Sparkles className="h-3.5 w-3.5 text-violet-300 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      <span className="text-[10px] uppercase tracking-wider text-violet-300/80 font-semibold">
                        AI Match · {aiSuggestion.confidence === 'high' ? 'High' : 'Medium'} confidence
                      </span>
                      <span className="text-[10px] font-mono text-violet-300/60">
                        ({aiSuggestion.score.toFixed(2)})
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-violet-200 shrink-0">
                        {aiSuggestion.reference}
                      </span>
                      <span className="text-[11px] text-muted-foreground truncate italic">
                        &ldquo;{aiSuggestion.text}&rdquo;
                      </span>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    onClick={sendAiSuggestionLive}
                    className="h-7 text-[10px] gap-1 bg-violet-600 hover:bg-violet-500 text-white shrink-0"
                  >
                    <Send className="h-3 w-3" />
                    Send Live
                  </Button>
                  <button
                    type="button"
                    onClick={() => setAiSuggestion(null)}
                    title="Dismiss"
                    className="text-violet-300/60 hover:text-violet-200 text-[14px] leading-none px-1"
                  >
                    ×
                  </button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Live Verse Display */}
        <AnimatePresence mode="wait">
          {liveVerse && (
            <motion.div
              ref={liveDisplayRef}
              key={liveVerse.reference}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.4 }}
              className={cn(
                'bg-gradient-to-br from-card to-card/80 border border-primary/20 rounded-xl overflow-hidden relative',
                isFullscreen && 'flex items-center justify-center min-h-screen',
              )}
            >
              {settings.customBackground && (
                <div className="absolute inset-0 rounded-xl overflow-hidden">
                  <img src={settings.customBackground} alt="" className="w-full h-full object-cover opacity-20" />
                  <div className="absolute inset-0 bg-black/40" />
                </div>
              )}
              <CardContent className={cn('p-8 md:p-12 relative', isFullscreen && 'max-w-4xl')}>
                <div className="flex items-center justify-between mb-4">
                  <Badge className="bg-primary/15 text-primary border-primary/20 text-xs">LIVE DETECTED</Badge>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-8 text-xs gap-1.5"
                      onClick={() => goLiveWithVerse({
                        reference: liveVerse.reference,
                        text: liveVerse.text,
                        translation: liveVerse.translation,
                      }, false)}
                    >
                      <Send className="h-3.5 w-3.5" />
                      Send to Live
                    </Button>
                    <Button variant="ghost" size="sm" className="h-8 text-xs lg:hidden" onClick={toggleFullscreen}>
                      <Maximize2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
                <div className="relative">
                  <p
                    className="text-2xl md:text-3xl lg:text-4xl font-medium text-foreground leading-relaxed text-center verse-highlight"
                    style={{ textShadow: settings.textShadow ? '0 2px 12px rgba(0,0,0,0.3)' : 'none' }}
                  >
                    {liveVerse.text}
                  </p>
                  <p className="text-center mt-6 text-base md:text-lg text-primary font-medium">
                    — {liveVerse.reference} ({liveVerse.translation})
                  </p>
                </div>
              </CardContent>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Detected Verses Sidebar */}
      <div className="w-full lg:w-80 border-t lg:border-t-0 lg:border-l border-border bg-card/30 flex flex-col shrink-0">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <div className="flex items-center gap-2">
            <BookOpen className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm font-medium">Detected ({detectedVerses.length})</span>
          </div>
          {detectedVerses.length > 0 && (
            <Button variant="ghost" size="sm" className="h-7 text-xs text-destructive" onClick={clearDetectedVerses}>
              <Trash2 className="h-3 w-3 mr-1" /> Clear
            </Button>
          )}
        </div>
        <ScrollArea className="flex-1">
          {detectedVerses.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
              <BookOpen className="h-8 w-8 text-muted-foreground/50 mb-2" />
              <p className="text-xs text-muted-foreground">Detected verses will appear here</p>
              {isListening && (
                <p className="text-[10px] text-muted-foreground/70 mt-1">
                  Listening in the background...
                </p>
              )}
            </div>
          ) : (
            <div className="flex flex-col gap-2 p-3">
              {detectedVerses.map((verse, i) => (
                <motion.div
                  key={verse.id}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className={cn(
                    'rounded-lg p-3 transition-colors cursor-pointer',
                    liveVerse?.reference === verse.reference
                      ? 'bg-primary/10 border border-primary/20'
                      : 'bg-muted/30 hover:bg-muted/50 border border-transparent',
                  )}
                  onClick={() => setLiveVerse({
                    reference: verse.reference,
                    text: verse.text,
                    translation: verse.translation,
                    book: '',
                    chapter: 0,
                    verseStart: 0,
                  })}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-primary">{verse.reference}</span>
                    <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {verse.detectedAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground line-clamp-3 leading-relaxed">{verse.text}</p>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-[10px] gap-1 mt-2 w-full"
                    onClick={(e) => { e.stopPropagation(); goLiveWithVerse(verse, false) }}
                  >
                    <Send className="h-3 w-3" />
                    Send to Live
                  </Button>
                </motion.div>
              ))}
            </div>
          )}
        </ScrollArea>
      </div>
    </div>
  )
}
